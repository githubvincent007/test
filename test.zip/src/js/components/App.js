import React, { Component, PropTypes } from 'react';
import DocumentTitle from 'react-document-title';
import Header from './header/header';
import Navigation from './navigation/Navigation';
require('./app.scss');


export default class App extends Component {
  static propTypes = {
    children: PropTypes.element.isRequired
  };

  render() {
    return (
      <DocumentTitle title='Ticker Search'>
      <div className="page-container" id="page-layout">
        <Header></Header>

        <div className="ui doubling one column centered page grid">
          <div className="column">
            <div className="main-section">
              <Navigation></Navigation>
              {this.props.children}
            </div>
          </div>
        </div>
      </div>
      </DocumentTitle>
    );
  }
}
