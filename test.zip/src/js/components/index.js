export { default as AddFriendInput } from './AddFriendInput/AddFriendInput';
export { default as FriendList } from './FriendList/FriendList';
