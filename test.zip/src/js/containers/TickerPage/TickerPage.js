/**
 * Created by vinay damarla on 9/22/2016.
 */
/**
 * Created by vinay damarla on 8/9/2016.
 */
import React, { Component } from 'react';
import {selectSearch, invalidateSearch, requestPosts, receivePosts, fetchPosts } from '../../actions/TickerActions';
require('./TickerPage.css');

class TickerPage extends Component {

  constructor (props) {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(e)  {

    var _search = this.refs.searchbox.value;
    console.log(this.refs.searchbox.value + "is dispatched");
    this.props.dispatch(fetchPosts(_search));
  }


  render () {


    return (
      <div>
        <h1>first page test</h1>
        <div className="ui padded segment sheet">
          <h1>&nbsp;&nbsp;&nbsp;&nbsp;Search For a Ticker: </h1>
          <div className="ui action fluid input">
            <input ref="searchbox" type="text" placeholder="Search..."></input>
            <button className="ui button" onClick={this.handleSubmit}>Search</button>
          </div>

        </div>

      </div>
    );
  }

}

function mapStateToProps(state) {
  return {

  };
}

//function mapDispatchToProps(dispatch) {
 // return {
 //   actions: bindActionCreators(TickerActions, dispatch)
 // };
//}

export default connect(
  mapStateToProps
  //mapDispatchToProps
)(TickerPage);



//export default TickerPage;
