/**
 * Created by vinay damarla on 8/9/2016.
 */
import React, { Component } from 'react';

require('./FirstPage.css');

class FirstPage extends Component {

  constructor (props) {
    super();
  }

  render () {


    return (
      <div>
        <h1>first page test</h1>
        <div className="ui padded segment sheet">
             

        </div>

      </div>
    );
  }

}

export default FirstPage;
