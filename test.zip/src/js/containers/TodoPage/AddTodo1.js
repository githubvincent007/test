import React from 'react'
import { connect } from 'react-redux' // the difference between class vs part
import { addTodo } from '../../actions/TodoActions'
import store from '../../store/configureStore'

let AddTodo1 = ({ dispatch }) => {
  let input

  return (
    <div>
      <form onSubmit={e => {
        e.preventDefault()
        if (!input.value.trim()) {
          return
        }
        dispatch(addTodo(input.value))
        input.value = ''
      }}>
        <input ref={node => {
          input = node
        }} />
        <button type="submit">
          Add Todo
        </button>
      </form>
    </div>
  )
}
AddTodo1 = connect()(AddTodo1)

export default AddTodo1
//these are components that do something and these are components that
// dont do antyhing 
