/**
 * Created by vinay damarla on 8/9/2016.
 */
import React, { Component } from 'react';
import Footer from '../../components/Todo/Footer'
import AddTodo1 from './AddTodo1'
import VisibleTodoList from './VisibleTodoList'

require('./ToDoPage.css');

class ToDoPage extends Component {

  constructor (props) {
    super();


  }

  render () {


    return (
      <div>
        <AddTodo1 />
        <VisibleTodoList />
        <Footer />
      </div>
    );
  }

}

export default ToDoPage;
