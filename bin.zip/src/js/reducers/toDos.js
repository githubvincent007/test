import * as types from '../constants/ActionTypes';
import { assign } from 'lodash';


const todo = (state = {}, action) => {
  switch (action.type) {
    case 'ADD_TODO':
      return {
        id: action.id,
        text: action.text,
        completed: false
      }
    case 'TOGGLE_TODO':
      if (state.id !== action.id) {
        return state
      }
      //this is reducer composition it can handle
      //just hte part that you neeed .
      //
      return Object.assign({}, state, {
        completed: !state.completed
      })

    default:
      return state
  }
}
// basically this is the initial state to begin with

const todos = (state = [], action) => {
  switch (action.type) {
    case 'ADD_TODO':
      return [
        ...state,
        todo(undefined, action)
      ]
    case 'TOGGLE_TODO':
      return state.map(t =>
        todo(t, action)
      )
    default:
      return state
  }
}

export default todos
