/**
 * Created by vinay damarla on 9/22/2016.
 */
/**
 * Created by vinay damarla on 8/9/2016.
 */
import React, { Component } from 'react';
import {selectSearch, invalidateSearch, requestPosts, receivePosts, fetchPosts } from '../../actions/TickerActions';

require('./TickerPage.css');
import { connect } from 'react-redux';

class TickerPage extends Component {

  constructor (props) {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(e)  {

    var _search = this.refs.searchbox.value;
    console.log(this.refs.searchbox.value + "is dispatched");
    this.props.dispatch(fetchPosts(_search));
  }

  renderDropDown() {

$(this.refs.OneHistLoad).dropdown();


  }


  componentDidMount() {
    this.renderDropDown();

  }

  componentDidUpdate() {
    this.renderDropDown();

  }


  render () {


    return (
     <div className="ui grid" style={{'overflow': 'auto'}}>
      <div className="row">
        <div className="left floated column">

          <div className="ui search">
            <div className="ui icon input">
              <input className="prompt" type="text" placeholder="Tickers Search..."/>
                <i className="search icon"/>
            </div>
            <div className="results"></div>
          </div>

          </div>
        </div>

      <div className="row">
        <div className="left floated column" >

      <table className="ui compact celled definition table" >
        <thead>
        <tr>
          <th>select</th>
          <th>Name</th>
          <th>MIO Name</th>
          <th>MIO Asset Class</th>
          <th>Country</th>
          <th>Currency</th>
          <th>One Time History Load</th>
          <th>Hist Restated Data</th>
          <th>Blmbg Pricing Src</th>
          <th>Future Restated Data</th>
          <th>Returns Measure</th>
          <th>Disable Ticker</th>
          <th>Derived Data</th>
          <th>End of Day Pr</th>
          <th>Estimates</th>
          <th>Fundamentals</th>
          <th>Hist Time Srs</th>
          <th>Sec Master</th>
          <th>User Entered</th>
          <th>Quote Comp</th>
          <th>Corp Action</th>
          <th>Credit Risk</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td className="collapsing">
            <div className="ui fitted checkbox">
              <input type="checkbox"></input>
            </div>
          </td>


            <td>
              {/* Name */}
              <div className="ui input">
                <input type="text" placeholder="Enter..."/>
              </div>

            </td>
          <td>
            {/*MIO Name */}
            <div className="ui input">
              <input type="text" placeholder="Enter..."/>
            </div>

          </td>
          <td>
            {/*Mio Asset Class  */}
            <div className="ui selection dropdown" ref="MioAssetClass">
              <input type="hidden" name="selection"/>
              <i className="dropdown icon"></i>
              <div className="default text">U.S.Equity</div>
              <div className="menu">
                <div className="item" data-value="1">US Equity</div>
                <div className="item" data-value="2">Credit</div>
                <div className="item" data-value="3">Fixed Income</div>
                <div className="item" data-value="4">Commodities</div>
              </div>
            </div>

          </td>


          <td>
            {/* Country  */}
            <div className="ui input">
              <input type="text" placeholder="Enter..."/>
            </div>

          </td>


          <td>
           {/* Currency */}
            <div className="ui input">
              <input type="text" placeholder="Enter..."/>
            </div>

          </td>


          <td>
            {/* 5 One Time Hist Load */}
            <div className="ui selection dropdown" ref="OneHistLoad">
              <input type="hidden" name="selection"/>
              <i className="dropdown icon"></i>
              <div className="default text">None</div>
              <div className="menu">
                <div className="item" data-value="1">one month</div>
                <div className="item" data-value="2">two month</div>
                <div className="item" data-value="3">three months</div>
                <div className="item" data-value="4">six months</div>
                <div className="item" data-value="5">one year</div>
                <div className="item" data-value="6">two years</div>
                <div className="item" data-value="7">five years</div>
                <div className="item" data-value="8">ten years</div>
                <div className="item" data-value="9">twenty years </div>
                <div className="item" data-value="10">thirty years</div>
              </div>
            </div>

          </td>

          <td>
            {/*  6 Historical Restated data */}
            <div className="ui selection dropdown" ref="HistRestatedData">
              <input type="hidden" name="selection"/>
              <i className="dropdown icon"></i>
              <div className="default text">None</div>
              <div className="menu">
                <div className="item" data-value="1">one month</div>
                <div className="item" data-value="2">two month</div>
                <div className="item" data-value="3">three months</div>
                <div className="item" data-value="4">six months</div>
                <div className="item" data-value="5">one year</div>
                <div className="item" data-value="6">two years</div>
                <div className="item" data-value="7">five years</div>
                <div className="item" data-value="8">ten years</div>
                <div className="item" data-value="9">twenty years </div>
                <div className="item" data-value="10">thirty years</div>
              </div>
            </div>

          </td>
          <td>
            {/*  7 Bloomberg Pricing Source */}
            <div className="ui selection dropdown" ref="BloombergPricing">
              <input type="hidden" name="selection"/>
              <i className="dropdown icon"></i>
              <div className="default text">Bloomberg</div>
              <div className="menu">
                <div className="item" data-value="1">Bloomberg</div>
                <div className="item" data-value="0">Bval</div>
              </div>
            </div>
          </td>

          <td>

            {/*  8 Future Restated data */}
            <div className="ui selection dropdown" ref="OneHistLoad">
              <input type="hidden" name="selection"/>
              <i className="dropdown icon"></i>
              <div className="default text">None</div>
              <div className="menu">
                <div className="item" data-value="1">one month</div>
                <div className="item" data-value="2">two month</div>
                <div className="item" data-value="3">three months</div>
                <div className="item" data-value="4">six months</div>
                <div className="item" data-value="5">one year</div>
                <div className="item" data-value="6">two years</div>
                <div className="item" data-value="7">five years</div>
                <div className="item" data-value="8">ten years</div>
                <div className="item" data-value="9">twenty years </div>
                <div className="item" data-value="10">thirty years</div>
              </div>
            </div>
        </td>
          <td>
            {/*  9 Primary Measure */}
            <div className="ui selection dropdown" ref="OneHistLoad">
              <input type="hidden" name="selection"/>
              <i className="dropdown icon"></i>
              <div className="default text">None</div>
              <div className="menu">
                <div className="item" data-value="1">None</div>
                <div className="item" data-value="0">Full</div>
              </div>
            </div>
          </td>
          <td>
            {/* 10 Disable Tickers */}
            <div class="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>

          </td>
          <td>
            {/* 11 Derived data */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>

          </td>
          <td>
            {/* 12 End of Day Pricing */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>

          </td>
          <td>
            {/* 13 Estimates */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>
          </td>
          <td>
            {/* 14 Fundamentals */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>

          </td>
          <td>

            {/* 15 Historical Time Series */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>

          </td>
          <td>
            {/* 16 Sec Master*/}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>

          </td>
          <td>
            {/* 17 User Entered */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>
          </td>
          <td>
            {/* 18 Quote-Comp */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>

          </td>
          <td>
            {/* 19 corp Actions */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>
          </td>
          <td>
            {/* 20 credit Risk */}
            <div className="ui fitted checkbox">
              <input type="checkbox" />
              <label></label>
            </div>
          </td>

        </tr>

        </tbody>
        <tfoot className="full-width">
        <tr>
          <th> </th>
          <th colSpan="21"  >
            <div className="ui right floated small primary labeled icon button">
              <i className="user icon"></i> Add Ticker
            </div>
            <div className="ui small button">
              Edit
            </div>
            <div className="ui small  disabled button">
              Save All
            </div>
          </th>
        </tr>
        </tfoot>
      </table>
          </div>
        </div>
       </div>
    );
  }

}

function mapStateToProps(state) {
  return {

  };
}

//function mapDispatchToProps(dispatch) {
 // return {
 //   actions: bindActionCreators(TickerActions, dispatch)
 // };
//}

export default connect(
  mapStateToProps
  //mapDispatchToProps
)(TickerPage);



//export default TickerPage;
