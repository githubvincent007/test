module.exports = {
  root: true,
  // https://github.com/airbnb/javascript
  extends: 'airbnb',
  // https://github.com/xjamundx/eslint-plugin-promise
  plugins: ['promise'],
  // Custom rules specific to MIO, 
  rules: {
    // No semicolons allowed! Exceptions allowed for
    // multiple statements within a single line
    semi: [2, "never"],
    // Enfoce specific line-break in files for windows or unix
    // systems. Disabled here as developers might touch same code
    // on different OSs, which will throw errors
    'linebreak-style': 0,
    // allow paren-less arrow functions
    'arrow-parens': 0,
    // allow debugger during development
    'no-debugger': process.env.NODE_ENV === 'production' ? 2 : 0
  }
}