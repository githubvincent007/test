import React from 'react'

function Column(props){
  const columnStyle = {
    marginLeft: props.style.marginLeft || null,
    flex: props.width ? `0 0 ${props.width}px` : null
  }
  return (
    <div className="Column" style={columnStyle}>{props.children}</div>
  )
}

export default Column