/**
 * 
 * The top-level wrapper component for your application. Use CSS to adjust
 * design as necessary for your application, and create more base templates
 * or nested child templates depending on the size of the app. Recommended
 * to insert only into VIEW components (see readme)
 *
 * Properties:
 * className : String
 *     Added to component, but prepended with root 'Base-' class to avoid
 *     CSS conflict. This is inline with BEM naming convention
 *     Example: <Base className='settings'>  =>  <div class="Base Base-settings"></div>
 *  
 */
import Base from './base'
import './base.styl'

export { Base }