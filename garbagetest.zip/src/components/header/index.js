/**
 *
 * Header component for consistent look and feel across pages. Uses flex
 * display to always vertically center child elements
 *
 * Properties:
 * height : Int : Optionally set custom height
 * 
 */
import Header from './header'
import './header.styl'

export { Header }