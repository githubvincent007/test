import React from 'react'
import { Link } from 'react-router'
import {Column, ColumnParent} from 'components/layout'
import { MioLogo } from 'components/mio-logo'

function Header(props){

  const style = (props.height) ? {
    height: props.height
  } : null;

  // TODO: Dynamically build nav links
  return (
    <div style={style} className="Header">
      <div className="layout--container">
        <ColumnParent align='edges' className="mio-header">
          <Column>
            <MioLogo />
          </Column>
          <Column width={600}>
            <ul className="nav">
              <li><Link to='/' className="link" activeClassName="active">Manage Tickers</Link></li>
            </ul>
          </Column>
        </ColumnParent>
      </div>
    </div>
  )
}

export default Header
