// config.js
// Application settings, constants and other global variables
// should be kept here for easier maintenance

// This is dynamically linked to specific environment passed in
// from script (in Webpack config)
import envConfig from 'envConfig'


// Settings here will be overwritten or extended by imported envConfig
// Use this to create env-specific variables and pass proper parameter
// when building project or running dev server
const config = {
  // Example variable which will be overwritten
  environment : null
}

// Merge base and environment config files
export default Object.assign({},config, envConfig)