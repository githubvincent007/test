// App.js
// Root component for our application
import React from 'react'

import { Base } from 'components/base'
import { Header } from 'components/header'

class App extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    // const childrenWithProps = React.Children.map(this.props.children,
    //   (child) => React.cloneElement(child, {
    //     isLoading: this.props.isLoading
    //   })
    // );

    return (
      <Base>
        <div id="app">
          <Header />
          <div id="primary-info">
            {this.props.children}
          </div>
        </div>
      </Base>
    )
  }
}

export default App;
