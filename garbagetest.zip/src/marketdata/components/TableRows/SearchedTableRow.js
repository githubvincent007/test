/**
 * Created by vinay damarla on 9/26/2016.
 */
/**
 * Created by webstorm on 9/25/2016.
 */
/**
 * Created by webstorm on 9/25/2016.
 */
/**
 * Created by webstorm on 9/25/2016.
 */

/* create something tablerowactions reducer for handling specific items for a row
 whereas there are global table rows these are specific to the rows actions
 */


import React, { Component, PropTypes } from 'react';
import classnames from 'classnames';

export default class SearchedTableRow extends Component {

  constructor (props) {
    super();


  }


/*
  static propTypes = {
    handleEdit1: React.PropTypes.func.isRequired
  };
*/
  //handleEdit(e)  {

  // this.props.dispatch(EDIT_A_ROW(this.props.rowData.Ticker_ID));
  // var _search = this.refs.searchbox.value;
  // console.log(this.refs.searchbox.value + "is dispatched");
  // this.props.dispatch(fetchPosts(_search));

  //}




  render () {
    return (
      <tr>
        <td className="collapsing">
          <button className="ui green button" onClick={(evt) =>this.props.handleEdit1(this.props.rowData.Ticker_ID)}>
            Edit
          </button>
        </td>


        <td>
          {/* Name */}
          {this.props.rowData.Name}

        </td>
        <td>
          {/*MIO Name */}
          {this.props.rowData.MIO_Name}
        </td>
        <td>
          {/*Mio Asset Class  */}

          {(() => {
            switch (this.props.rowData.MIO_Asset_Class) {
              case 1: return <div>US EQUITY</div> ;
              case 2: return <div>CREDIT</div>;
              case 3: return <div>FIXED INCOME</div>;
              case 4: return <div>COMMODITIES</div>;
              default:      return <div>NONE</div>;
            }
          })()}
        </td>


        <td>
          {/* Country  */}
          {this.props.rowData.Country}

        </td>


        <td>
          {/* Currency */}
          {this.props.rowData.Currency}

        </td>


        <td>
          {/* 5 One Time Hist Load */}

          {(() => {
            switch (this.props.rowData.One_Time_History_Load) {
              case 1: return <div>One Month</div> ;
              case 2: return <div>One Year</div>;
              case 3: return <div>Two Years</div>;
              case 4: return <div>Five Years</div>;
              default:      return <div>NONE</div>;
            }
          })()}
        </td>

        <td>
          {/*  6 Historical Restated data  // {this.props.rowData.Hist_Restated_Data} */}

          {(() => {
            switch (this.props.rowData.Hist_Restated_Data) {
              case 1: return <div>One Month</div> ;
              case 2: return <div>One Year</div>;
              case 3: return <div>Two Years</div>;
              case 4: return <div>Five Years</div>;
              default:      return <div>NONE</div>;
            }
          })()}
        </td>
        <td>
          {/*  7 Bloomberg Pricing Source    {this.props.rowData.Blmbg_Pricing_Src} */}

          {(() => {
            switch (this.props.rowData.Blmbg_Pricing_Src) {
              case 1: return <div>Bloomberg</div> ;
              case 2: return <div>Bval</div>;
              case 3: return <div>Source1</div>;
              case 4: return <div>Source2</div>;
              default:      return <div>NONE</div>;
            }
          })()}
        </td>

        <td>

          {/*  8 Future Restated data  {this.props.rowData.Future_Restated_Data} */}

          {(() => {
            switch (this.props.rowData.Future_Restated_Data) {
              case 1: return <div>One Month</div> ;
              case 2: return <div>One Year</div>;
              case 3: return <div>Two Years</div>;
              case 4: return <div>Five Years</div>;
              default:      return <div>NONE</div>;
            }
          })()}
        </td>
        <td>
          {/*  9 Primary Measure  {this.props.rowData.Returns_Measure} */}

          {(() => {
            switch (this.props.rowData.Returns_Measure) {
              case 1: return <div>One Month</div> ;
              case 2: return <div>One Year</div>;
              case 3: return <div>Two Years</div>;
              case 4: return <div>Five Years</div>;
              default:      return <div>NONE</div>;
            }
          })()}

        </td>
        <td>
          {/* 10 Disable Tickers */}
          {(() => {
            switch (this.props.rowData.Disable_Ticker) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>
        <td>
          {/* 11 Derived data */}
          {(() => {
            switch (this.props.rowData.Derived_Data) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>
        <td>
          {/* 12 End of Day Pricing */}
          {(() => {
            switch (this.props.rowData.End_of_Day_Pr) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>
        <td>
          {/* 13 Estimates */}
          {(() => {
            switch (this.props.rowData.Estimates) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>
        <td>
          {/* 14 Fundamentals */}
          {(() => {
            switch (this.props.rowData.Fundamentals) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}

        </td>
        <td>
          {/* 15 Hist Time Series */}

          {(() => {
            switch (this.props.rowData.Hist_Time_Srs) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>
        <td>
          {/* 16 Sec Master*/}
          {(() => {
            switch (this.props.rowData.Sec_Master) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>
        <td>
          {/* 17 User Entered */}
          {(() => {
            switch (this.props.rowData.User_Entered) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}

        </td>
        <td>
          {/* 18 Quote-Comp */}
          {(() => {
            switch (this.props.rowData.Quote_Comp) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>
        <td>
          {/* 19 corp Actions */}
          {(() => {
            switch (this.props.rowData.Corp_Action) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}

        </td>

        <td>
          {/* 20 credit Risk */}
          {(() => {
            switch (this.props.rowData.Credit_Risk) {
              case true:   return <td className="center aligned"><i className="large green checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>

        <td>
          {/* 21 ticker id */}
          <div className="ui label ">
            <div className="detail center aligned">{this.props.rowData.Ticker_ID}  </div>
          </div>
        </td>

        <td>
          {/* 22 row status */}
          <a className="ui label">{this.props.rowData.Row_Status} </a>
        </td>
        <td>
          {/* 23 Is Dirty */}
          {(() => {
            switch (this.props.rowData.Is_Dirty) {
              case 1:   return <td className="center aligned"><i className="large black checkmark icon"></i></td>;
              case 0: return <div></div>;
              default:      return <div></div>;
            }
          })()}
        </td>


      </tr>
    );
  }
}
