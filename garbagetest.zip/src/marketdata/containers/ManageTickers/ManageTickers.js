import React, {Component, PropTypes} from 'react';
//import ReactDataGrid from 'react-data-grid';

import NewTableRow from '../../components/TableRows/NewTableRow';
import SearchedTableRow from '../../components/TableRows/SearchedTableRow';
import EditTableRow from '../../components/TableRows/EditTableRow';
import SavedTableRow from '../../components/TableRows/SavedTableRow';

import {  fetchPosts2 } from '../../../state/actions';
class ManageTickers extends Component {

  constructor (props) {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleNewTicker = this.handleNewTicker.bind(this);
    this.handleEdit = this.handleEdit.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.handleEnter = this.handleEnter.bind(this);
    this.state = {currentNewId:-1};
  }

  handleNewTicker(e)
  {
    this.setState({currentNewId: this.state.currentNewId-1});


    this.props.actions.NEW_TICKER_ROW(this.state.currentNewId);

  }

  handleEdit(row_tickerid)  {

    this.props.actions.EDIT_A_ROW(row_tickerid);

  }




  handleSave(row_tickerid)  {

    this.props.actions.SAVE_A_ROW(row_tickerid);

  }



  handleSubmit(e)  {

    // var _search = this.refs.searchbox.value;
    // console.log(this.refs.searchbox.value + "is dispatched");
    // this.props.dispatch(fetchPosts(_search));
  }

  handleEnter(e)
  {
    if(e.charCode === 13)
    {
      e.preventDefault(); // Ensure it is only this code that rusn

      var _search = this.refs.searchbox.value;
      console.log(this.refs.searchbox.value + "is dispatched");
      this.props.postactions.fetchPosts(_search);
     // this.props.dispatch(fetchPosts(_search));
     // alert("Enter was pressed was presses");
    }

  }



  renderDropDown() {

    //$(this.refs.OneHistLoad).dropdown();

}

  componentDidMount() {
 // $(this.refs.OneHistLoad).dropdown();
  }

  componentDidUpdate() {
 //   this.renderDropDown();

  }

  render () {

    var displayRows = this.props.tableRows.map(function(_ROW){


      switch (_ROW.Row_Status) {
        case "NEW":   return <NewTableRow rowData={_ROW}/>;
        case "EDIT": return  <EditTableRow rowData={_ROW} handleSave={this.handleSave}/>;
        case "SAVED": return  <SavedTableRow rowData={_ROW}/>;
        case "SEARCHED":   return <SearchedTableRow rowData={_ROW} handleEdit1={this.handleEdit}/>;
        default:      return <NewTableRow rowData={_ROW}/>;
      }

      /*saved will be same as new for now */




    }, this);








    return (

      <div className="ui grid" style={{'overflow': 'auto'}}>
        <div className="row">
          <div className="left floated column">

            <div className="ui search" style={{padding: 50}}>
              <div className="ui icon input">
                <input className="prompt" ref="searchbox" type="text" placeholder="Tickers Search..." onKeyPress={this.handleEnter}/>
                <i className="search icon"/>
              </div>
              <div className="results"></div>
            </div>

          </div>
        </div>

        <div className="row">
          <div className="left floated column" style={{padding:50}} >

            <table className="ui small collapsing celled definition table" >
              <thead>
              <tr>
                <th colSpan="1"></th>
                <th colSpan="5">General</th>
                <th colSpan="5">Loading</th>
                <th colSpan="11">License Categories</th>
                <th colSpan="3">Meta</th>
              </tr>
              <tr>
                <th>select</th>
                <th>Name</th>
                <th>MIO Name</th>
                <th>MIO Asset Class</th>
                <th>Country</th>
                <th>Currency</th>
                <th>One Time History Load</th>
                <th>Hist Restated Data</th>
                <th>Blmbg Pricing Src</th>
                <th>Future Restated Data</th>
                <th>Returns Measure</th>
                <th>Disable Ticker</th>
                <th>Derived Data</th>
                <th>End of Day Pr</th>
                <th>Estimates</th>
                <th>Fundamentals</th>
                <th>Hist Time Srs</th>
                <th>Sec Master</th>
                <th>User Entered</th>
                <th>Quote Comp</th>
                <th>Corp Action</th>
                <th>Credit Risk</th>
                <th>Ticker ID</th>
                <th>Row Status</th>
                <th>Is Dirty</th>
              </tr>
              </thead>
              <tbody>
              {displayRows}

              </tbody>
              <tfoot className="full-width">
              <tr>
                <th> </th>
                <th colSpan="24"  >
                  <div className="ui left floated small primary labeled icon button" onClick={this.handleNewTicker}>
                    <i className="user icon"></i> Add Ticker
                  </div>
                  {/*   <div className="ui small button">
                   Edit
                   </div>
                   <div className="ui small  disabled button">
                   Save All
                   </div>  */}
                </th>
              </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    );
  }


}

export default ManageTickers;
