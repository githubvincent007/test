// reducers.js
import config from 'config'
export  { initialState, reducer }

import {
  PRIMARY_EXAMPLE_ACTION, RECEIVE_POSTS
} from 'state/action-types.js'


const initialState = {
  name: false,
  session: null,
  posts: []
}

// Never mutate original state passed in. Read
// on redux principles
function reducer(state = initialState, action){

  switch (action.type) {

    case PRIMARY_EXAMPLE_ACTION: {
      return Object.assign({}, state, {
        name: action.name
      })

    }
          /* we no longer need to receive it bc
          the add a search row would handle it
          and the clear, clears the rows in state
          this is deprecated.
           */
    case RECEIVE_POSTS:
    {
      return Object.assign({}, state, {
        posts: action.posts
      })

    }
  }

  return state
}
