import {
  SELECT_SEARCH, INVALIDATE_SEARCH,
  REQUEST_POSTS, RECEIVE_POSTS
} from '../action-types'


const posts = (state = {
  isFetching: false,
  didInvalidate: false,
  items: []
}, action) => {
  switch (action.type) {
    case INVALIDATE_SEARCH:
      return Object.assign({}, state, {
        didInvalidate: true
      })
    case REQUEST_POSTS:
      return Object.assign({}, state, {
        isFetching: true,
        didInvalidate: false
      })
    case RECEIVE_POSTS:
      return Object.assign({}, state, {
        isFetching: false,
        didInvalidate: false,
        items: action.posts,
        lastUpdated: action.receivedAt
      })
    default:
      return state
  }
}





export default function PostsBySearch(state = initialState.PostsBySearches, action) {
  switch (action.type) {
    case INVALIDATE_SEARCH:
    case RECEIVE_POSTS:
    case REQUEST_POSTS:
      return Object.assign({}, state, {
        [action.search]: posts(state[action.search], action)
      })
    default:
      return state
  }
}
