var request = require('superagent');
var Promise = require("bluebird");
var jwt = require('jsonwebtoken');
var jwtMiddleware = require('express-jwt');
const binaryParser = require('superagent-binary-parser');
const fs = require('fs');
var api = require('./utils.js')
var http = require('http');

exports.getNames = (req, res) => {
  api.get({ 
    method:'get_csd_partner_search',
    query: req.query
  }).then(function(data){
    res.json(data)
  })
};
