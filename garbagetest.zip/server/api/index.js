
var Promise = require("bluebird");
var jwt = require('jsonwebtoken');
var express = require('express');
var jwtMiddleware = require('express-jwt');


const search = require('./search')
const users = require('./users')
const vantage = require('./vantage')
const interaction = require('./interaction')
const offerings = require('./offerings')


var router = express.Router();

router.get('/search', search.getNames);

router.get('/authenticate', users.authenticate);
router.get('/validate', users.validateToken);

// Necessary parameters are passed along to routes as queries
router.get('/vantage/balances', vantage.getBalances);
router.get('/vantage/transactions', vantage.getTransactions);
router.get('/vantage/statements', vantage.getStatements);
router.get('/vantage/single-statement', vantage.getSingleStatementLink);

router.get('/interaction/profile', interaction.getProfileInfo);

router.get('/offerings/transactions', offerings.getTransactions);

module.exports = router;

