var request = require('superagent');
var Promise = require("bluebird");
var jwt = require('jsonwebtoken');
var jwtMiddleware = require('express-jwt');
const binaryParser = require('superagent-binary-parser');
const fs = require('fs');
var api = require('./utils.js')
var http = require('http');

// http://devchi-lnx-ws01:5755/mass/cs_resource/get_ia_info_fmno?fmno=15623922
// http://localhost:8080/api/interaction/profile?fmno=79805998
exports.getProfileInfo = (req, res) => {
  api.get({
    method:'get_ia_info_fmno',
    query: req.query
  }).then(function(data){
    res.json(data)
  })
};

// http://devchi-lnx-ws01:5855/mass/cs_resource/get_mio_lastlogin_fmno?fmno=18863880
// http://localhost:8080/api/interaction/last-portal-login?fmno=18863880
exports.lastPortalLogin = (req, res) => {
  api.get({
    method:'get_mio_lastlogin_fmno',
    query: req.query
  }).then(function(data){
    res.json(data)
  })
}

