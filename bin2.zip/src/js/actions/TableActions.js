/**
 * Created by webstorm on 9/24/2016.
 */
import * as types from '../constants/ActionTypes';

//export const NEW_TICKER_ROW = e => ({
//type: ADD_A_NEW_TICKER_ROW,
//  new_row: e
//})

export function NEW_TICKER_ROW(_id) {
  return {
    type: types.ADD_A_NEW_TICKER_ROW,
    id: _id
  };
}


export function ADD_SEARCHED_TICKER_ROW(_row) {
  return {
    type: types.ADD_A_SEARCHED_ROW,
    searchedRow: _row
  };
}


export function EDIT_A_ROW(_row_id) {
  return {
    type: types.EDIT_A_ROW,
    row_tickerid: _row_id
  };
}
