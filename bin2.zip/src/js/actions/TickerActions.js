import {
  REQUEST_POSTS, RECEIVE_POSTS, SELECT_SEARCH, INVALIDATE_SEARCH
} from '../constants/ActionTypes.js'

import request from 'superagent';

export const selectSearch = Search => ({
  type: SELECT_SEARCH,
  Search
})

export const invalidateSearch = Search => ({
  type: INVALIDATE_SEARCH,
  Search
})

export const requestPosts = Search => ({
  type: REQUEST_POSTS,
  Search
})

export const receivePosts = (Search, json) => ({
  type: RECEIVE_POSTS,
  Search,
  SearchResults: json,
  receivedAt: Date.now()
})

export const fetchPosts = Search => dispatch => {
  dispatch(requestPosts(Search));
  request('GET', 'http://127.0.0.1:8000/marketdata_api/ticker_search?search='+Search)
    .set('Accept', 'application/json')
    .then(
      function(success){
        console.log(success.text);
        dispatch(receivePosts(Search, JSON.parse(success.text)))

      }, function(failure){
        console.log(failure);}
    );
}










