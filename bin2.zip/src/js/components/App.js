import React, { Component, PropTypes } from 'react';
import DocumentTitle from 'react-document-title';
import Header from './header/header';
import Navigation from './navigation/Navigation';
require('./app.scss');


export default class App extends Component {
  static propTypes = {
    children: PropTypes.element.isRequired
  };

  render() {
    return (




        <div className=" ui left floated">


              {this.props.children}


      </div>

    );
  }
}
