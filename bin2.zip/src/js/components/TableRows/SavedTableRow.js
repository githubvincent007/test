/**
 * Created by webstorm on 9/25/2016.
 */
/**
 * Created by webstorm on 9/25/2016.
 */


import React, { Component, PropTypes } from 'react';
import classnames from 'classnames';

export default class SavedTableRow extends Component {

  static propTypes = {

  };

  render () {
    return (
      <div/>
    );
  }
}
