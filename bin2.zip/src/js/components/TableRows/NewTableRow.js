/**
 * Created by webstorm on 9/25/2016.
 */


import React, { Component, PropTypes } from 'react';
import classnames from 'classnames';

export default class NewTableRow extends Component {

  static propTypes = {

  };

  render () {
    // take each of these and map them
    // run the component will and did mount shits

    return (
      <tr>
        <td className="collapsing">
          {/*--<div className="ui fitted checkbox">
            <input type="checkbox"></input>
          </div> */}

        </td>


        <td>
          {/* Name */}
          <div className="ui input">
            <input type="text" placeholder="Enter..."/>
          </div>

        </td>
        <td>
          {/*MIO Name */}
          <div className="ui input">
            <input type="text" placeholder="Enter..."/>
          </div>

        </td>
        <td>
          {/*Mio Asset Class  */}
          <div className="ui selection dropdown" ref="MioAssetClass">
            <input type="hidden" name="selection"/>
            <i className="dropdown icon"></i>
            <div className="default text">U.S.Equity</div>
            <div className="menu">
              <div className="item" data-value="1">US Equity</div>
              <div className="item" data-value="2">Credit</div>
              <div className="item" data-value="3">Fixed Income</div>
              <div className="item" data-value="4">Commodities</div>
            </div>
          </div>

        </td>


        <td>
          {/* Country  */}
          <div className="ui input">
            <input type="text" placeholder="Enter..."/>
          </div>

        </td>


        <td>
          {/* Currency */}
          <div className="ui input">
            <input type="text" placeholder="Enter..."/>
          </div>

        </td>


        <td>
          {/* 5 One Time Hist Load */}
          <div className="ui selection dropdown" ref="OneHistLoad">
            <input type="hidden" name="selection"/>
            <i className="dropdown icon"></i>
            <div className="default text">None</div>
            <div className="menu">
              <div className="item" data-value="1">one month</div>
              <div className="item" data-value="2">two month</div>
              <div className="item" data-value="3">three months</div>
              <div className="item" data-value="4">six months</div>
              <div className="item" data-value="5">one year</div>
              <div className="item" data-value="6">two years</div>
              <div className="item" data-value="7">five years</div>
              <div className="item" data-value="8">ten years</div>
              <div className="item" data-value="9">twenty years </div>
              <div className="item" data-value="10">thirty years</div>
            </div>
          </div>

        </td>

        <td>
          {/*  6 Historical Restated data */}
          <div className="ui selection dropdown" ref="HistRestatedData">
            <input type="hidden" name="selection"/>
            <i className="dropdown icon"></i>
            <div className="default text">None</div>
            <div className="menu">
              <div className="item" data-value="1">one month</div>
              <div className="item" data-value="2">two month</div>
              <div className="item" data-value="3">three months</div>
              <div className="item" data-value="4">six months</div>
              <div className="item" data-value="5">one year</div>
              <div className="item" data-value="6">two years</div>
              <div className="item" data-value="7">five years</div>
              <div className="item" data-value="8">ten years</div>
              <div className="item" data-value="9">twenty years </div>
              <div className="item" data-value="10">thirty years</div>
            </div>
          </div>

        </td>
        <td>
          {/*  7 Bloomberg Pricing Source */}
          <div className="ui selection dropdown" ref="BloombergPricing">
            <input type="hidden" name="selection"/>
            <i className="dropdown icon"></i>
            <div className="default text">Bloomberg</div>
            <div className="menu">
              <div className="item" data-value="1">Bloomberg</div>
              <div className="item" data-value="0">Bval</div>
            </div>
          </div>
        </td>

        <td>

          {/*  8 Future Restated data */}
          <div className="ui selection dropdown" ref="OneHistLoad">
            <input type="hidden" name="selection"/>
            <i className="dropdown icon"></i>
            <div className="default text">None</div>
            <div className="menu">
              <div className="item" data-value="1">one month</div>
              <div className="item" data-value="2">two month</div>
              <div className="item" data-value="3">three months</div>
              <div className="item" data-value="4">six months</div>
              <div className="item" data-value="5">one year</div>
              <div className="item" data-value="6">two years</div>
              <div className="item" data-value="7">five years</div>
              <div className="item" data-value="8">ten years</div>
              <div className="item" data-value="9">twenty years </div>
              <div className="item" data-value="10">thirty years</div>
            </div>
          </div>
        </td>
        <td>
          {/*  9 Primary Measure */}
          <div className="ui selection dropdown" ref="OneHistLoad">
            <input type="hidden" name="selection"/>
            <i className="dropdown icon"></i>
            <div className="default text">None</div>
            <div className="menu">
              <div className="item" data-value="1">None</div>
              <div className="item" data-value="0">Full</div>
            </div>
          </div>
        </td>
        <td>
          {/* 10 Disable Tickers */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>

        </td>
        <td>
          {/* 11 Derived data */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>

        </td>
        <td>
          {/* 12 End of Day Pricing */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>

        </td>
        <td>
          {/* 13 Estimates */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>
        </td>
        <td>
          {/* 14 Fundamentals */}

          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>

        </td>
        <td>

          {/* 15 Historical Time Series */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>

        </td>
        <td>
          {/* 16 Sec Master*/}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>

        </td>
        <td>
          {/* 17 User Entered */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>
        </td>
        <td>
          {/* 18 Quote-Comp */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>

        </td>
        <td>
          {/* 19 corp Actions */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>
        </td>

        <td>
          {/* 20 credit Risk */}
          <div className="ui fitted checkbox">
            <input type="checkbox" />
            <label></label>
          </div>
        </td>

        <td>
          {/* 21 ticker id */}
          <div class="ui label">
            <div class="detail">{this.props.rowData.Ticker_ID}  </div>
          </div>
        </td>

        <td>
          {/* 22 row status */}
          <a className="ui blue label">{this.props.rowData.Row_Status}</a>
        </td>
        <td>
          {this.props.rowData.Is_Dirty==1 ? <i className="large black checkmark icon"></i> : <div className="ui green label">No</div> }
        </td>

      </tr>
    );
  }
}
