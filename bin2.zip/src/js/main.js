//import '../styles/bootstrap.min.css';
//import '../styles/styles.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import configureStore  from './store/configureStore';
import { Router, browserHistory } from 'react-router';
import {ADD_SEARCHED_TICKER_ROW} from './actions/TableActions';

import routes from './routes';

const store = configureStore();
const rootElement = document.getElementById('app');

let ComponentEl;

if (process.env.NODE_ENV !== 'production') {
 const DevTools = require('./containers/DevTools').default;

  // If using routes
  ComponentEl = (
    <div>
      <Router history={browserHistory} routes={routes} />
     { <DevTools /> }
     </div>
  );
} else {
  ComponentEl = (
    <div>
      <Router history={browserHistory} routes={routes} />
    </div>
  );
}

var new_row =    {
  Name:  "VINAY CORP" ,
  MIO_Name:  "VINAY MIO NAME" ,
  MIO_Asset_Class:  "VINAY ASSET CLASS" ,
  Country:  "LAND OF VINAY" ,
  Currency:  "VINAY BUCKS" ,
  One_Time_History_Load:  1,
  Hist_Restated_Data:  1 ,
  Blmbg_Pricing_Src:  1 ,
  Future_Restated_Data:  1,
  Returns_Measure:  1 ,
  Disable_Ticker: true ,
  Derived_Data:  true ,
  End_of_Day_Pr:  true ,
  Estimates:  true ,
  Fundamentals: true ,
  Hist_Time_Srs:  true ,
  Sec_Master:  true ,
  User_Entered:  true ,
  Quote_Comp:  true ,
  Corp_Action:  true,
  Credit_Risk:  true,
  Ticker_ID:  5456,
  Row_Status:  "SEARCHED",
  Is_Dirty: 0
};


store.dispatch(ADD_SEARCHED_TICKER_ROW(new_row));
//store.dispatch(ADD_SEARCHED_TICKER_ROW(new_row));
//store.dispatch(NEW_TICKER_ROW(-1));
//store.dispatch(NEW_TICKER_ROW(-2));
//store.dispatch(NEW_TICKER_ROW(-3));




// Render the React application to the DOM
ReactDOM.render(
  <Provider store={store}>
    {ComponentEl}
  </Provider>,
  rootElement
);
