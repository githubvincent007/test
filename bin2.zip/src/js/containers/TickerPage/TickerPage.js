/**
 * Created by vinay damarla on 9/22/2016.
 */
/**
 * Created by vinay damarla on 8/9/2016.
 */
import React, { Component } from 'react';
import {bindActionCreators} from 'redux';
//import {selectSearch, invalidateSearch, requestPosts, receivePosts, fetchPosts } from '../../actions/TickerActions';
//{NEW_TICKER_ROW, EDIT_A_ROW}
import * as tableActions from '../../actions/TableActions';
//import * as FriendsActions
import NewTableRow from '../../components/TableRows/NewTableRow';
import SearchedTableRow from '../../components/TableRows/SearchedTableRow';
import EditTableRow from '../../components/TableRows/EditTableRow';

//import {EDIT_A_ROW} from '../../actions/TableActions';
/* when you range a row, all your fields get send up and marked as isdirty
when you hit save its a global svae that goes and finds everythign taht is isdirty and
then sends them up by calling the individual save_row on each of them
 */

require('./TickerPage.css');
import { connect } from 'react-redux';

class TickerPage extends Component {

  constructor (props) {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleNewTicker = this.handleNewTicker.bind(this);
    this.handleEdit = this.handleEdit.bind(this);
    this.state = {currentNewId:-1};
  }

  handleNewTicker(e)
  {
    this.setState({currentNewId: this.state.currentNewId-1});


    this.props.actions.NEW_TICKER_ROW(this.state.currentNewId);
    // alert('got clicked');
  }


  handleEdit(row_tickerid)  {
//alert('got hit');
    this.props.actions.EDIT_A_ROW(row_tickerid);

  }

  handleSubmit(e)  {

   // var _search = this.refs.searchbox.value;
   // console.log(this.refs.searchbox.value + "is dispatched");
   // this.props.dispatch(fetchPosts(_search));
  }

  renderDropDown() {

    $(this.refs.OneHistLoad).dropdown();



  }


  componentDidMount() {
//    this.renderDropDown();
    $(this.refs.OneHistLoad).dropdown();
  }

  componentDidUpdate() {
    this.renderDropDown();

  }





  render () {
    //  f = this.handleEdit;
  var displayRows = this.props.tableRows.map(function(_ROW){


        switch (_ROW.Row_Status) {
          case "NEW":   return <NewTableRow rowData={_ROW}/>;
          case "EDIT": return  <EditTableRow rowData={_ROW}/>;
          case "SAVED": return "#00FF00";
          case "SEARCHED":   return <SearchedTableRow rowData={_ROW} handleEdit1={this.handleEdit}/>;
          default:      return <NewTableRow rowData={_ROW}/>;
        }




      }, this);








    return (
     <div className="ui grid" style={{'overflow': 'auto'}}>
      <div className="row">
        <div className="left floated column">

          <div className="ui search">
            <div className="ui icon input">
              <input className="prompt" type="text" placeholder="Tickers Search..."/>
                <i className="search icon"/>
            </div>
            <div className="results"></div>
          </div>

          </div>
        </div>

      <div className="row">
        <div className="left floated column" style={{padding:50}} >

      <table className="ui small collapsing celled definition table" >
        <thead>
        <tr>
          <th>select</th>
          <th>Name</th>
          <th>MIO Name</th>
          <th>MIO Asset Class</th>
          <th>Country</th>
          <th>Currency</th>
          <th>One Time History Load</th>
          <th>Hist Restated Data</th>
          <th>Blmbg Pricing Src</th>
          <th>Future Restated Data</th>
          <th>Returns Measure</th>
          <th>Disable Ticker</th>
          <th>Derived Data</th>
          <th>End of Day Pr</th>
          <th>Estimates</th>
          <th>Fundamentals</th>
          <th>Hist Time Srs</th>
          <th>Sec Master</th>
          <th>User Entered</th>
          <th>Quote Comp</th>
          <th>Corp Action</th>
          <th>Credit Risk</th>
          <th>Ticker ID</th>
          <th>Row Status</th>
          <th>Is Dirty</th>
        </tr>
        </thead>
        <tbody>
        {displayRows}

        </tbody>
        <tfoot className="full-width">
        <tr>
          <th> </th>
          <th colSpan="24"  >
            <div className="ui left floated small primary labeled icon button" onClick={this.handleNewTicker}>
              <i className="user icon"></i> Add Ticker
            </div>
            {/*   <div className="ui small button">
              Edit
            </div>
            <div className="ui small  disabled button">
              Save All
            </div>  */}
          </th>
        </tr>
        </tfoot>
      </table>
          </div>
        </div>
       </div>
    );
  }

}

function mapStateToProps(state) {
//x123;
//  var for_debug ="x1234";Ticker_ID

  return {
    tableRows: state.table.Rows
     // tableRows: state.

  };
}

function mapDispatchToProps(dispatch) {
  return {
     actions: bindActionCreators(tableActions, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TickerPage);



//export default TickerPage;
