/**
 * Created by webstorm on 9/24/2016.
 */
/**
 * Created by vinay damarla on 9/22/2016.
 */


import {
  ADD_A_NEW_TICKER_ROW, ADD_A_SEARCHED_ROW, EDIT_A_ROW
} from '../constants/ActionTypes.js'


const initialState = {
  Rows :[]
}




// Never mutate original state passed in. Read
// on redux principles
export default function rowsReducer(state = initialState, action) {

  switch (action.type) {


    case ADD_A_NEW_TICKER_ROW: {
      return Object.assign({}, state, {
        Rows: [
          ...state.Rows,
          {
            Name: "",
            MIO_Name: "",
            MIO_Asset_Class: "",
            Country: "",
            Currency: "",
            One_Time_History_Load: "",
            Hist_Restated_Data: "",
            Blmbg_Pricing_Src: "",
            Future_Restated_Data: "",
            Returns_Measure: "",
            Disable_Ticker: "",
            Derived_Data: "",
            End_of_Day_Pr: "",
            Estimates: "",
            Fundamentals: "",
            Hist_Time_Srs: "",
            Sec_Master: "",
            User_Entered: "",
            Quote_Comp: "",
            Corp_Action: "",
            Credit_Risk: "",
            Ticker_ID: action.id,
            Row_Status: "NEW",
            Is_Dirty: 0
          }
        ]
      })

    }
    case ADD_A_SEARCHED_ROW: {
      /* MAKE SURE TO CLEAR OUT THE ROWS FROM THE RECEIVE_POSTS BEFORE DISPATCHIGN EACH OF THEESE
       MAKE SURE TO USE AN JAVACRIPT MAPPER FUNCTION TO MOVE IT INTO OUR STATE TYPE
       */
      return Object.assign({}, state, {
        Rows: [
          ...state.Rows,
          {
            Name: action.searchedRow.Name,
            MIO_Name: action.searchedRow.MIO_Name,
            MIO_Asset_Class: action.searchedRow.MIO_Asset_Class,
            Country: action.searchedRow.Country,
            Currency: action.searchedRow.Currency,
            One_Time_History_Load: action.searchedRow.One_Time_History_Load,
            Hist_Restated_Data: action.searchedRow.Hist_Restated_Data,
            Blmbg_Pricing_Src: action.searchedRow.Blmbg_Pricing_Src,
            Future_Restated_Data: action.searchedRow.Future_Restated_Data,
            Returns_Measure: action.searchedRow.Returns_Measure,
            Disable_Ticker: action.searchedRow.Disable_Ticker,
            Derived_Data: action.searchedRow.Derived_Data,
            End_of_Day_Pr: action.searchedRow.End_of_Day_Pr,
            Estimates: action.searchedRow.Estimates,
            Fundamentals: action.searchedRow.Fundamentals,
            Hist_Time_Srs: action.searchedRow.Hist_Time_Srs,
            Sec_Master: action.searchedRow.Sec_Master,
            User_Entered: action.searchedRow.User_Entered,
            Quote_Comp: action.searchedRow.Quote_Comp,
            Corp_Action: action.searchedRow.Corp_Action,
            Credit_Risk: action.searchedRow.Credit_Risk,
            Ticker_ID: action.searchedRow.Ticker_ID,
            Row_Status: "SEARCHED",
            Is_Dirty: action.searchedRow.Is_Dirty
          }
        ]
      })


    }
    case EDIT_A_ROW: {

      return Object.assign({}, state, {
        Rows: state.Rows.map((_row)=> {
          if (_row.Ticker_ID === action.row_tickerid) {
            return Object.assign({}, _row, {Row_Status: "EDIT"})
          }
        })


      })
    }
    default:
      return state;
  }



}
