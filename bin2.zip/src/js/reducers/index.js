import { combineReducers } from 'redux'; //lets use this other library
import friendList from './friendList';
import todos from './toDos';
import visibilityFilter from './visibilityFilter';
import tickersReducer from './tickersReducer';
import table from './table';

const rootReducer = combineReducers({
  todos, table
});

export default rootReducer;

/* why didn't the combine_reducer work for our project
 */
