/**
 * Created by vinay damarla on 9/22/2016.
 */
/**
 * Created by vinay damarla on 8/9/2016.
 */
import React, { Component } from 'react';
import {selectSearch, invalidateSearch, requestPosts, receivePosts, fetchPosts } from '../../actions/TickerActions';

require('./TickerPage.css');
import { connect } from 'react-redux';

class TickerPage extends Component {

  constructor (props) {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(e)  {

    var _search = this.refs.searchbox.value;
    console.log(this.refs.searchbox.value + "is dispatched");
    this.props.dispatch(fetchPosts(_search));
  }

  renderDropDown() {

$(this.refs.OneHistLoad).dropdown();


  }


  componentDidMount() {
    this.renderDropDown();

  }

  componentDidUpdate() {
    this.renderDropDown();

  }


  render () {


    return (
     <div className="ui grid" style={{'overflow': 'auto'}}>
      <div className="row">
        <div className="left floated column">

          <div className="ui search">
            <div className="ui icon input">
              <input className="prompt" type="text" placeholder="Tickers Search..."/>
                <i className="search icon"/>
            </div>
            <div className="results"></div>
          </div>

          </div>
        </div>

      <div className="row">
        <div className="left floated column" >

      <table className="ui compact celled definition table" >
        <thead>
        <tr>
          <th>select</th>
          <th>Name</th>
          <th>MIO Name</th>
          <th>MIO Asset Class</th>
          <th>Country</th>
          <th>Currency</th>
          <th>One Time History Load</th>
          <th>Hist Restated Data</th>
          <th>Blmbg Pricing Src</th>
          <th>Future Restated Data</th>
          <th>Returns Measure</th>
          <th>Disable Ticker</th>
          <th>Derived Data</th>
          <th>End of Day Pr</th>
          <th>Estimates</th>
          <th>Fundamentals</th>
          <th>Hist Time Srs</th>
          <th>Sec Master</th>
          <th>User Entered</th>
          <th>Quote Comp</th>
          <th>Corp Action</th>
          <th>Credit Risk</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td className="collapsing">
            <div className="ui fitted checkbox">
              <input type="checkbox"></input>
            </div>
          </td>


            <td>
              {/* Name */}
              <div className="ui input">
                <input type="text" placeholder="Enter..."/>
              </div>

            </td>
          <td>
            {/*Mio Asset Class  */}
            <div className="ui selection dropdown">
              <input type="hidden" name="selection"/>
              <i className="dropdown icon"></i>
              <div className="default text">Gender</div>
              <div className="menu">
                <div className="item" data-value="1">Male</div>
                <div className="item" data-value="0">Female</div>
              </div>
            </div>

          </td>


          <td>
            {/* Country  */}
            <div className="ui input">
              <input type="text" placeholder="Enter..."/>
            </div>

          </td>


          <td>

            {/* Currency */}
            <div className="ui input">
              <input type="text" placeholder="Enter..."/>
            </div>

          </td>


          <td>
            {/* One Time Hist Load */}
            <div className="ui selection dropdown" ref="OneHistLoad">
              <input type="hidden" name="selection"/>
              <i className="dropdown icon"></i>
              <div className="default text">Gender</div>
              <div className="menu">
                <div className="item" data-value="1">Male</div>
                <div className="item" data-value="0">Female</div>
              </div>
            </div>

          </td>

          <td>6</td>
          <td>7</td>
          <td>8</td>
          <td>9</td>
          <td>10</td>
          <td>11</td>
          <td>12</td>
          <td>13</td>
          <td>14</td>
          <td>15</td>
          <td>16</td>
          <td>17</td>
          <td>18</td>
          <td>19</td>
          <td>20</td>
          <td>21</td>
        </tr>

        </tbody>
        <tfoot className="full-width">
        <tr>
          <th> </th>
          <th colSpan="21"  >
            <div className="ui right floated small primary labeled icon button">
              <i className="user icon"></i> Add Ticker
            </div>
            <div className="ui small button">
              Edit
            </div>
            <div className="ui small  disabled button">
              Save All
            </div>
          </th>
        </tr>
        </tfoot>
      </table>
          </div>
        </div>
       </div>
    );
  }

}

function mapStateToProps(state) {
  return {

  };
}

//function mapDispatchToProps(dispatch) {
 // return {
 //   actions: bindActionCreators(TickerActions, dispatch)
 // };
//}

export default connect(
  mapStateToProps
  //mapDispatchToProps
)(TickerPage);



//export default TickerPage;
