/**
 * Created by vinay damarla on 8/10/2016.
 */
/**
 * Created by vinay damarla on 8/9/2016.
 */
import React, { Component } from 'react';
import {Navigation} from 'react-router';
import { browserHistory , Router} from 'react-router';


require('./NavigationBar.css');

class NavigationBar extends Component {



  constructor (props) {
    super();

    this.handleClick = this.handleClick.bind(this);
    this.handleGoBackClick = this.handleGoBackClick.bind(this);

    this.state = {
      page_value:0
    };

  }



  handleClick(e) {
    e.preventDefault();

    this.state.page_value = this.state.page_value + 1;
    if(this.state.page_value==1)
    {
      browserHistory.push('/second');
    }
    if(this.state.page_value==2)
    {
      browserHistory.push('/third');

    }
    if(this.state.page_value==3)
    {
      browserHistory.push('/todo');
      this.state.page_value = 0;
    }
  }

  handleGoBackClick(e) {
    e.preventDefault();

    browserHistory.goBack();
  }


  render () {


    return (
      <div className="ui grid">
        <div className=" column row">
          <div className="left floated column fullbody">
            <div className="ui buttons">
              <button className="ui labeled icon button" onClick={this.handleGoBackClick}>
                <i className="left chevron icon"></i>
                Back
              </button>
            </div>
            </div>
            <div className="right floated column fullbody">
              <div className="ui buttons">
                <button className="ui right labeled icon button" onClick={this.handleClick}>
                  <i className="right chevron icon"></i>Forward
                </button>
              </div>
            </div>
          </div>
        </div>);
  }

}

export default  NavigationBar;
