/**
 * Created by vinay damarla on 9/22/2016.
 */


import {
  PRIMARY_EXAMPLE_ACTION, RECEIVE_POSTS
} from '../constants/ActionTypes.js'


const initialState = {
  recentSearches: '',
  searchRows: [],
  isFetching: false
}


// Never mutate original state passed in. Read
// on redux principles
export default function tickersReducer(state = initialState, action){

  switch (action.type) {

    case PRIMARY_EXAMPLE_ACTION: {
      return Object.assign({}, state, {
        name: action.name
      })

    }
    case RECEIVE_POSTS:
    {
      return Object.assign({}, state, {
        searchRows: action.SearchResults
      })

    }
  }

  return state
}
