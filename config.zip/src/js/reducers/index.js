import { combineReducers } from 'redux'; //lets use this other library
import friendList from './friendList';
import todos from './toDos';
import visibilityFilter from './visibilityFilter';
import tickersReducer from './tickersReducer';

const rootReducer = combineReducers({
  todos,tickersReducer
});

export default rootReducer;
