import React from 'react';
import {browserHistory ,Route, IndexRoute, Redirect } from 'react-router';

import App from './components/App';
import FirstPage from './containers/FirstPage/FirstPage';
import TickerPage from './containers/TickerPage/TickerPage';

import FriendListPage from './containers/FriendListApp/FriendListApp';
import NotFoundView from './views/NotFoundView';

export default (
  <Route path="/" history={browserHistory} component={App}>
    <IndexRoute component={TickerPage} />
    <Route path="/first" component={FirstPage} />

    <Route path="/friendlist" component={FriendListPage} />
  <Redirect from="*" to="404" />
  </Route>
);
