/**
 * Created by vinay damarla on 9/22/2016.
 */
/**
 * Created by vinay damarla on 8/9/2016.
 */
import React, { Component } from 'react';
import {selectSearch, invalidateSearch, requestPosts, receivePosts, fetchPosts } from '../../actions/TickerActions';
require('./TickerPage.css');
import { connect } from 'react-redux';

class TickerPage extends Component {

  constructor (props) {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(e)  {

    var _search = this.refs.searchbox.value;
    console.log(this.refs.searchbox.value + "is dispatched");
    this.props.dispatch(fetchPosts(_search));
  }


  render () {


    return (
      <table className="ui compact celled definition table">
        <thead>
        <tr>
          <th></th>
          <th>Name</th>
          <th>Registration Date</th>
          <th>E-mail address</th>
          <th>Premium Plan</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td className="collapsing">
            <div className="ui fitted  checkbox">
              <input type="checkbox"/>
            </div>
          </td>
          <td>John Lilki</td>
          <td>September 14, 2013</td>
          <td>jhlilk22@yahoo.com</td>
          <td>No</td>
        </tr>
        <tr>
          <td className="collapsing">
            <div className="ui fitted  checkbox">
              <input type="checkbox"/>
            </div>
          </td>
          <td>Jamie Harington</td>
          <td>January 11, 2014</td>
          <td>jamieharingonton@yahoo.com</td>
          <td>Yes</td>
        </tr>
        <tr>
          <td className="collapsing">
            <div className="ui fitted  checkbox">
              <input type="checkbox"/>
            </div>
          </td>
          <td>Jill Lewis</td>
          <td>May 11, 2014</td>
          <td>jilsewris22@yahoo.com</td>
          <td>Yes</td>
        </tr>
        </tbody>
        <tfoot className="full-width">
        <tr>
          <th  ></th>
          <th colSpan="4"  >
            <div className="ui right floated small primary labeled icon button">
              <i className="user icon"></i> Add User
            </div>
            <div className="ui small button">
              Approve
            </div>
            <div className="ui small  disabled button">
              Approve All
            </div>
          </th>
        </tr>
        </tfoot>
      </table>
    );
  }

}

function mapStateToProps(state) {
  return {

  };
}

//function mapDispatchToProps(dispatch) {
 // return {
 //   actions: bindActionCreators(TickerActions, dispatch)
 // };
//}

export default connect(
  mapStateToProps
  //mapDispatchToProps
)(TickerPage);



//export default TickerPage;
