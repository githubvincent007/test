// CURRENTLY NOT BEING USED. NEEDED?
// 
// 
// var ExtractTextPlugin = require('extract-text-webpack-plugin')

// module.exports = function (options) {
//   options = options || {}
//   // generate loader string to be used with extract text plugin
//   function generateLoaders (loaders) {
//     console.log('loaders')
//     console.log(loaders)

    
//     var sourceLoader = loaders.map(function (loader) {
//       var extraParamChar
//       if (/\?/.test(loader)) {
//         loader = loader.replace(/\?/, '-loader?')
//         extraParamChar = '&'
//       } else {
//         loader = loader + '-loader'
//         extraParamChar = '?'
//       }
//       return loader + (options.sourceMap ? extraParamChar + 'sourceMap' : '')
//     }).join('!')

//     if (options.extract) {
//       console.log(['style-loader', sourceLoader].join('!'))
//       return ExtractTextPlugin.extract('style-loader', sourceLoader)
//     } else {
//       // return {
//       //   test :
//       // }
//       return ['style-loader', sourceLoader].join('!')
//     }
//   }

//   var test = {
//         css: generateLoaders(['css']),
//     postcss: generateLoaders(['css']),
//     less: generateLoaders(['css', 'less']),
//     sass: generateLoaders(['css', 'sass?indentedSyntax']),
//     scss: generateLoaders(['css', 'sass']),
//     stylus: generateLoaders(['css', 'stylus']),
//     styl: generateLoaders(['css', 'stylus'])
//   }
//   console.log('TEST')
//   console.log(test)

//   // http://vuejs.github.io/vue-loader/configurations/extract-css.html
//   return {
//     css: generateLoaders(['css']),
//     postcss: generateLoaders(['css']),
//     less: generateLoaders(['css', 'less']),
//     sass: generateLoaders(['css', 'sass?indentedSyntax']),
//     scss: generateLoaders(['css', 'sass']),
//     stylus: generateLoaders(['css', 'stylus']),
//     styl: generateLoaders(['css', 'stylus'])
//   }
// }
//   //   {
//   //     test: /\.css$/,
//   //     loader: ExtractTextPlugin.extract('style-loader', 'css-loader')
//   //   }