var path = require('path')
var config = require('../config')
var autoprefixer = require('autoprefixer');
var projectRoot = path.resolve(__dirname, '../')

const ENV_OPTIONS = ['dev', 'qa', 'stg', 'prod'];

// For grabbing passed parameters
var argv = require('minimist')(process.argv.slice(2));

var env = argv.env
if (!env) {
  console.log('  No environment set, defaulting to \'dev\'')
  env = 'dev'
} else if (ENV_OPTIONS.indexOf(env)===-1){
  console.log(`  ${env} not a valid option for env, reverting to 'dev'. Check /settings/webpack.base.js for options`)
  env = 'dev'
} else {
  console.log(`  Environment set to ${env}`)
}
var envConfig = path.resolve(__dirname, `../src/config/config.${env}.js`)

module.exports = {
  entry: {
    app: './src/index.js'
  },
  output: {
    path: config.build.assetsRoot,
    publicPath: config.build.assetsPublicPath,
    filename: '[name].js'
  },
  resolve: {
    extensions: ['', '.js', '.jsx'],
    root : [path.join(__dirname, '../src')],
    fallback: [path.join(__dirname, '../node_modules')],
    alias: {
      'theme': path.resolve(__dirname, '../src/styles/variables.styl'),
      'config': path.resolve(__dirname, `../src/config/config.base.js`),
      'envConfig' : envConfig 
    }
  },
  resolveLoader: {
    fallback: [path.join(__dirname, '../node_modules')]
  },
  module: {
    // preLoaders: [
    //   {
    //     test: /\.js$/,
    //     loader: 'eslint',
    //     include: projectRoot,
    //     exclude: /node_modules/
    //   }
    // ],
    loaders: [
      {
        test: /\.js$/,
        loaders: ['react-hot', 'babel'],
        include: projectRoot,
        exclude: /node_modules/
      },
      {
        test: /\.json$/,
        loader: 'json'
      },
      {
        test: /\.(png|jpe?g|gif|svg|eot|ttf|otf)(\?.*)?$/,
        loader: 'url',
        query: {
          limit: 10000,
          name: path.join(config.build.assetsSubDirectory, '[name].[hash:7].[ext]')
        }
      },
      {
        test: /\.(woff2?)(\?.*)?$/,
        loader: 'url',
        query: {
          name: path.join(config.build.assetsSubDirectory, '[name].[ext]')
        }
      },
    ]
  },
  postcss: function () {
        return [autoprefixer];
  },
  eslint: {
    formatter: require('eslint-friendly-formatter')
  }
}
