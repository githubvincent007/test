
// Example service for authentication
const Auth = { 
  login(username, password) {
  },
  validateSession() {
    return true
  },
  logout(){
    
  }
}

export default Auth


  
