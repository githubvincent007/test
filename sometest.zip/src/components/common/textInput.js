import React, {PropTypes} from 'react';

const TextInput = ({name, label, onChange, placeholder, value, error}) => {
/*  let wrapperClass = 'form-group';
  if (error && error.length > 0) {
    wrapperClass += " " + 'has-error';
  }*/

  return (
    /*<div className={wrapperClass}>*/
    <div>
      {label && <label htmlFor={name}>{label}</label>}
      <div className="ui fluid action input">
          <input
          type="text"
          name={name}
          placeholder={placeholder}
          value={value}
          onChange={onChange}/>
        {error && <div className="alert">{error}</div>}
      </div>
    </div>
  );
};

TextInput.propTypes = {
  name: PropTypes.string.isRequired,
  label: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  placeholder: PropTypes.string,
  value: PropTypes.string,
  error: PropTypes.string
};

export default TextInput;

