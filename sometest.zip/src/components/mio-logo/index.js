import React from 'react'

// Assuming correct setup in webpack, this will be data-encoded directly
// into <img /> tag
import logoSrc from './mio-logo.svg'

function MioLogo(props) {
  return <img src={logoSrc} />
}

export { MioLogo }