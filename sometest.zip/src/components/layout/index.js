/**
 * Layout: Set of basic components to help structure page blocks
 * Dependencies: classnames, stlyus for CSS
 *
 * Usage:
 * <ColumnParent>
 *   <Column></Column>
 *   <Column></Column>
 *   <Column>
 *     <ColumnParent>
 *       <Column></Column>
 *       <Column></Column>
 *     </ColumnParent>
 *   </Column>
 * </ColumnParent>
 *
 * Where <Column> is always a direct child of <ColumnParent>
 * Columns are spaced out even utilizing Flex, though can be given
 * extra attributes to further refine styling
 * <ColumnParent
 *   align=
 *   className=
 *   gutter=
 * <Column
 *   width=
 * 
 * 
 */

import Column from './column'
import ColumnParent from './column-parent'
import './layout.styl'
export { Column, ColumnParent }