import React from 'react'
import classNames from 'classnames'

// Validated via PropTypes in development mode
const alignOptions = ['left', 'right', 'center', 'edges', 'initial']

function ColumnParent (props){

  var ColumnParentClass =classNames({
    'ColumnParent': true,
    'ColumnParent--gutter': !!props.gutter,
    [`ColumnParent--${props.align}`]: !!props.align 
  }, props.className)


  var ColumnParentStyle = {
    marginLeft: props.gutter ? -(props.gutter) : null, 
  }

  return (
    <div className={ColumnParentClass} style={ColumnParentStyle}>
      {React.Children.map(props.children, child=>{

        return React.cloneElement(child, {
          style: {
            marginLeft: props.gutter || null,
          },
          className: 'test',
          test: true
        })
      })}
    </div>
  )
}


ColumnParent.propTypes = {
  align: React.PropTypes.oneOf(alignOptions),
}
    


export default ColumnParent