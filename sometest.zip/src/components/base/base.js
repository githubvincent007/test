// App.js
// Root component for our application
import React from 'react'

function Base({className, children}) {
  // This should always match component name
  const rootClass = 'Base'
  
  let baseClass = rootClass
  // Prepend root class to any other classes passed down to avoid conflict
  if (className) {
    baseClass += ' ' + className.split(' ').map(c=>`${rootClass}-${c}`).join(' ')
  }
  
  return (
    <div className={baseClass}>      
      {children}
    </div>
  )
}



export default Base
