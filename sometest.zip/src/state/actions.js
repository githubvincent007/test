import Promise from 'bluebird'
import request from 'superagent'
//import Auth from 'auth'

import config from 'config'

// Actions are payloads of information that send data from your application to your store.
// They are the only source of information for the store.

import {
PRIMARY_EXAMPLE_ACTION,
SECONDARY_EXAMPLE_ACTION
} from './action-types.js'


export const exampleAction = name => ({
  type: PRIMARY_EXAMPLE_ACTION,
  name
})

export const fetchpost2 = name => ({
  type: PRIMARY_EXAMPLE_ACTION,
  name
})
