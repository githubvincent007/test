// All available actions to mutate state are stored here and
// imported as needed into action and reducer files. This allows
// you to see at a glance all possible mutations to client and
// session data

// Group alphabetically or by module
export const PRIMARY_EXAMPLE_ACTION = 'PRIMARY_EXAMPLE_ACTION'
export const SECONDARY_EXAMPLE_ACTION = 'SECONDARY_EXAMPLE_ACTION'
export const REQUEST_SEARCH = 'REQUEST_SEARCH'
export const RECEIVE_SEARCH = 'RECEIVE_SEARCH'
export const SELECT_SEARCH = 'SELECT_SEARCH'
export const INVALIDATE_SEARCH = 'INVALIDATE_SEARCH'
export const ADD_A_NEW_TICKER_ROW = 'ADD_NEW_TICKER_ROW';
export const ADD_A_SEARCHED_TICKER = 'ADD_A_SEARCHED_TICKER';
export const EDIT_A_ROW = 'EDIT_A_ROW';
export const SAVE_A_ROW = 'SAVE_A_ROW';
export const SAVE_A_NEW_TICKER_SUCCESS = 'SAVE_A_NEW_TICKER_SUCCESS';
export const CLEAR_ROWS = 'CLEAR_ROWS';

export const REQUEST_DAYS_REQUESTED_LIST = 'REQUEST_DAYS_REQUESTED_LIST'
export const RECEIVE_DAYS_REQUESTED_LIST = 'RECEIVE_DAYS_REQUESTED_LIST'
