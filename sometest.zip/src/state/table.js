/**
 * Created by vinay damarla on 9/26/2016.
 */

import request from 'superagent'

import {
  ADD_A_NEW_TICKER_ROW, ADD_A_SEARCHED_TICKER, EDIT_A_ROW, SAVE_A_ROW,
  CLEAR_ROWS
} from 'state/action-types.js';


const initialState = {
  tickers :[],
  reducer: {}
}




// Never mutate original state passed in. Read
// on redux principles
export default function rowsReducer(state = initialState.tickers, action) {

  switch (action.type) {

    case CLEAR_ROWS:
    {
       return [];
    }

  case ADD_A_NEW_TICKER_ROW: {
      return [
        ...state,
        Object.assign({},{
          Name: "",
          MIO_Name: "",
          MIO_Asset_Class: "",
          Country: "",
          Currency: "",
          One_Time_History_Load: "",
          Hist_Restated_Data: "",
          Blmbg_Pricing_Src: "",
          Future_Restated_Data: "",
          Returns_Measure: "",
          Disable_Ticker: "",
          Derived_Data: "",
          End_of_Day_Pr: "",
          Estimates: "",
          Fundamentals: "",
          Hist_Time_Srs: "",
          Sec_Master: "",
          User_Entered: "",
          Quote_Comp: "",
          Corp_Action: "",
          Credit_Risk: "",
          Ticker_ID: action.id,
          Row_Status: "NEW",
          Is_Dirty: 0
        } )
      ]

    }
    case ADD_A_SEARCHED_TICKER: {
      /* MAKE SURE TO CLEAR OUT THE ROWS FROM THE RECEIVE_POSTS BEFORE DISPATCHIGN EACH OF THEESE
       MAKE SURE TO USE AN JAVACRIPT MAPPER FUNCTION TO MOVE IT INTO OUR STATE TYPE
       //make a converstion of 31 to 1 month
       */


        return [
          ...state,
          Object.assign({},{
            Name: action.searchedRow.NAME,
            MIO_Name: action.searchedRow.MIO_NAME,
            MIO_Asset_Class: 1,
            Country: action.searchedRow.COUNTRY,
            Currency: action.searchedRow.CRNCY,
            One_Time_History_Load: action.searchedRow.DAYS_REQUESTED_FULL_HISTORY_ID,
            Hist_Restated_Data: action.searchedRow.DAYS_REQUESTED_FUTURE_ID,
            Blmbg_Pricing_Src: action.searchedRow.SYSTEM_ID,
            Future_Restated_Data: action.searchedRow.DAYS_REQUESTED_HISTORY_ID,
            Returns_Measure: 1,
            Disable_Ticker: action.searchedRow.IS_TICKER_DISABLED,
            Derived_Data: action.searchedRow.LIC_CAT_DERIVED_DATA,
            End_of_Day_Pr: action.searchedRow.LIC_CAT_END_OF_DAY_PRICING,
            Estimates: action.searchedRow.LIC_CAT_ESTIMATES,
            Fundamentals: action.searchedRow.LIC_CAT_FUNDAMENTALS,
            Hist_Time_Srs: action.searchedRow.LIC_CAT_HISTORICAL_TIME_SERIES,
            Sec_Master: action.searchedRow.LIC_CAT_SECURITY_MASTER,
            User_Entered: action.searchedRow.LIC_CAT_USER_ENTERED_INFO,
            Quote_Comp: action.searchedRow.LIC_QUOTE_COMPOSITE,
            Corp_Action: action.searchedRow.LIC_CORPORATE_ACTIONS,
            Credit_Risk: action.searchedRow.LIC_CREDIT_RISK,
            Ticker_ID: action.searchedRow.TICKER_ID,
            Row_Status: "SEARCHED",
            Is_Dirty: 0
          })
        ]



    }
    case EDIT_A_ROW: {


      return state.map((_row)=>{ if(_row.Ticker_ID==action.row_tickerid){ return Object.assign({}, _row, {Row_Status: "EDIT"}) }else {return _row} });



    }
    case SAVE_A_ROW:{
/* now here we find that negative ticker row update both its update
both the row status as well as the the ticker id !!
 */

      request
        .post('/marketdata_api/save_ticker/')
        .send(action.save_a_row)
        .set('X-API-Key', 'foobar')
        .set('Accept', 'application/json')
        .end(function(err, res){
          if (err || !res.ok) {
            alert('Oh no! error');
            console.log(err);
          } else {
           // console.log('yay got ' + JSON.stringify(res.body));
            var new_tickerid = (JSON.parse(res.text))[0].TICKER_ID;
            return state.map((_row)=>{ if(_row.Ticker_ID==action.row_tickerid){ return Object.assign({}, _row, {Row_Status: "SAVE", Ticker_ID: new_tickerid}) }else {return _row} });


            alert('success');

          }
        });

      /*
      return Object.assign({}, state, {
        Rows: state.Rows.map((_row)=> {
          if(_row != undefined) {
            if (_row.Ticker_ID == action.row_tickerid) {
              return Object.assign({}, _row, {Row_Status: "SAVED"})
            }
          }
        })


      }) */
    }
    default:
      return state;
  }



}
