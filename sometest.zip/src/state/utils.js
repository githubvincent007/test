import request from 'superagent'
import Promise from 'bluebird'

/**
 * TODO
 * Helper function for API requests
 * @param  {Boolean} options.url   [description]
 * @param  {Object}  options.query [description]
 * @return {[type]}                [description]
 */
export function api({
  url = false,
  query = {},
  // Assume private call since mostly used for rest API
  // This adds Bearer token to request header
}) {

  return new Promise((resolve, reject)=> {

    try {

      request
        .get(url)
        .query(query)
        .set('Accept', 'application/json')
        .end(function (err, res) {


          if (err) {
            console.error('ERROR')
            console.error(err)
            reject(err)
            return
          }


          if (res.status !== 200) {
            console.error(res.body)
            reject(res.body)
            return
          }


          resolve(res.body)
          return


        })

    } catch (e) {
      console.error('NOO!')
      console.log(e)
      reject(500)
    }

  })
}
