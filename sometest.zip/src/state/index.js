import { createStore, applyMiddleware, compose } from 'redux'
import thunkMiddleware from 'redux-thunk'
import createLogger from 'redux-logger'
import {combineReducers } from 'redux';
import {ADD_SEARCHED_TICKER} from 'state/ticker/actions'; //Tableactions

import { initialState, reducer } from 'state/reducers'
import tickers from './table'


const rootReducer = combineReducers({
  reducer, tickers
});

const loggerMiddleware = createLogger({
  collapsed: true,
  timestamp: false,
  duration: true
})



const store = createStore(
  rootReducer,
  initialState,
  compose(
    applyMiddleware(
      thunkMiddleware,
      loggerMiddleware
    ),
    window.devToolsExtension ? window.devToolsExtension() : f => f
  ))


/*var new_row =    {
  Name:  "VINAY CORP" ,
  MIO_Name:  "VINAY MIO NAME" ,
  MIO_Asset_Class:  1 ,
  Country:  "LAND OF VINAY" ,
  Currency:  "VINAY BUCKS" ,
  One_Time_History_Load:  1,
  Hist_Restated_Data:  1 ,
  Blmbg_Pricing_Src:  1 ,
  Future_Restated_Data:  1,
  Returns_Measure:  1 ,
  Disable_Ticker: true ,
  Derived_Data:  true ,
  End_of_Day_Pr:  true ,
  Estimates:  true ,
  Fundamentals: true ,
  Hist_Time_Srs:  true ,
  Sec_Master:  true ,
  User_Entered:  true ,
  Quote_Comp:  true ,
  Corp_Action:  true,
  Credit_Risk:  true,
  Ticker_ID:  5456,
  Row_Status:  "SEARCHED",
  Is_Dirty: 0
};
*/
var new_json = {

  index: 0,
    TICKER_ID: 3888,
  SYSTEM_ID: 1,
  SYSTEM_NAME: "Bloomberg",
  TICKER_CODE: "IBM UN Equity",
  ISIN_ID: "US4592001014",
  CUSIP_ID: "459200101",
  SEDOL_ID: null,
  NAME: "INTL BUSINESS MACHINES CORP",
  MIO_NAME: null,
  COUNTRY: "US",
  CRNCY: "USD ",
  LAST_LOAD_DT: "2013-11-26T00:00:00.000Z",
  LAST_VALUATION_DT: "2013-11-26T00:00:00.000Z",
  FIRST_VALUATION_DT: "1900-01-01T00:00:00.000Z",
  DAYS_REQUESTED_HISTORY_ID: 31,
  DAYS_REQUESTED_FUTURE_ID: 0,
  DAYS_REQUESTED_FULL_HISTORY_ID: 0,
  TICKER_TYPE_ID: 6,
  TICKER_TYPE_NM: "Equity",
  IS_TICKER_DISABLED: true,
  IS_GET_FULL_HISTORY: false,
  LIC_CAT_DERIVED_DATA: true,
  LIC_CAT_END_OF_DAY_PRICING: true,
  LIC_CAT_ESTIMATES: false,
  LIC_CAT_FUNDAMENTALS: false,
  LIC_CAT_HISTORICAL_TIME_SERIES: false,
  LIC_CAT_SECURITY_MASTER: true,
  LIC_CAT_USER_ENTERED_INFO: false,
  LIC_QUOTE_COMPOSITE: false,
  LIC_CORPORATE_ACTIONS: false,
  LIC_CREDIT_RISK: false,
  LIC_NOT_DOWNLOADABLE: false
};



store.dispatch(ADD_SEARCHED_TICKER(new_json));

var new_json = {

  index: 0,
  TICKER_ID: 4778,
  SYSTEM_ID: 1,
  SYSTEM_NAME: "BVAL",
  TICKER_CODE: "UNITY",
  ISIN_ID: "US4592001014",
  CUSIP_ID: "459200101",
  SEDOL_ID: null,
  NAME: "FBS SYSTEMS CORP",
  MIO_NAME: null,
  COUNTRY: "US",
  CRNCY: "USD ",
  LAST_LOAD_DT: "2013-11-26T00:00:00.000Z",
  LAST_VALUATION_DT: "2013-11-26T00:00:00.000Z",
  FIRST_VALUATION_DT: "1900-01-01T00:00:00.000Z",
  DAYS_REQUESTED_HISTORY_ID: 31,
  DAYS_REQUESTED_FUTURE_ID: 0,
  DAYS_REQUESTED_FULL_HISTORY_ID: 0,
  TICKER_TYPE_ID: 6,
  TICKER_TYPE_NM: "Equity",
  IS_TICKER_DISABLED: true,
  IS_GET_FULL_HISTORY: false,
  LIC_CAT_DERIVED_DATA: true,
  LIC_CAT_END_OF_DAY_PRICING: true,
  LIC_CAT_ESTIMATES: false,
  LIC_CAT_FUNDAMENTALS: false,
  LIC_CAT_HISTORICAL_TIME_SERIES: false,
  LIC_CAT_SECURITY_MASTER: true,
  LIC_CAT_USER_ENTERED_INFO: false,
  LIC_QUOTE_COMPOSITE: false,
  LIC_CORPORATE_ACTIONS: false,
  LIC_CREDIT_RISK: false,
  LIC_NOT_DOWNLOADABLE: false
};



store.dispatch(ADD_SEARCHED_TICKER(new_json));




export default store



