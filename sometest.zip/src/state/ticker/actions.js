import {
  REQUEST_SEARCH, RECEIVE_SEARCH, SELECT_SEARCH, INVALIDATE_SEARCH, ADD_A_SEARCHED_TICKER, REQUEST_DAYS_REQUESTED_LIST,RECEIVE_DAYS_REQUESTED_LIST
} from '../action-types.js'

import {api} from 'state/utils'

import request from 'superagent';

export const selectSearch = Search => ({
  type: SELECT_SEARCH,
  Search
})

export const invalidateSearch = Search => ({
  type: INVALIDATE_SEARCH,
  Search
})

export const requestSearch = Search => ({
  type: REQUEST_SEARCH,
  Search
})
/*basically we must do the following..a) clear out the
rows state, and then for each item in the call add a new
search row
 */
export const receiveSearch = (Search, json) => dispatch => {
 // type: RECEIVE_POSTS,
//  Search,
//  posts: json,
 // receivedAt: Date.now()

  json.forEach( function(_json){
    dispatch(ADD_SEARCHED_TICKER(_json) );
  })


}

export function ADD_SEARCHED_TICKER(_json) {
  return {
    type: ADD_A_SEARCHED_TICKER,
    searchedRow: _json
  };
}
/*
export const requestDaysRequestedList = (_data) ({
  type: REQUEST_DAYS_REQUESTED_LIST
})

 */

export const DAYS_REQUESTED_LIST = dispatch => {
  dispatch(requestDaysRequestedList());
  request('GET','/marketdata_api/days_requested_list')
    .set('Accept', 'application/json')
    .then(
      function(success){
        console.log(success.text);
        dispatch(receiveDaysRequestedList( JSON.parse(success.text)))

      }, function(failure){
        console.log(failure);});

}

export const fetchSearch = Search => dispatch => {
  dispatch(requestSearch(Search));
  request('GET', '/marketdata_api/ticker_search?search='+Search)
    .set('Accept', 'application/json')
    .then(
    function(success){
      console.log(success.text);
      dispatch(receiveSearch(Search, JSON.parse(success.text)))

      }, function(failure){
    console.log(failure);});


  //return fetch(`http://127.0.0.1:8000/marketdata_api/ticker_search?search=${Search}`)
   // .then(response => response.json())
   // .then(json => dispatch(receivePosts(Search, json)))
}

//http://127.0.0.1:8000/marketdata_api/ticker_search?search=APPL

//export const REQUEST_POSTS = 'REQUEST_POSTS'
//export const RECEIVE_POSTS = 'RECEIVE_POSTS'
//export const SELECT_SEARCH = 'SELECT_SEARCH'
//export const INVALIDATE_SEARCH = 'INVALIDATE_SEARCH'

function onGradeError(stuff){
  alert("Hello! It didt work!!");

}
