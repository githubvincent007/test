/**
 * Created by vinay damarla on 9/26/2016.
 */
//import * as types from '../constants/ActionTypes';


import * as types from '../action-types.js';

//export const NEW_TICKER_ROW = e => ({
//type: ADD_A_NEW_TICKER_ROW,
//  new_row: e
//})

export function NEW_TICKER_ROW(_id) {
  return {
    type: types.ADD_A_NEW_TICKER_ROW,
    id: _id
  };
}

export function CLEAR_ROWS() {
  return {
    type: types.CLEAR_ROWS 
  };
}



export function EDIT_A_ROW(_row_id) {
  return {
    type: types.EDIT_A_ROW,
    row_tickerid: _row_id
  };
}


export function SAVE_A_ROW(_row_id, _save_a_row) {
  return {
    type: types.SAVE_A_ROW,
    row_tickerid: _row_id,
    save_a_row: _save_a_row
  };
}
