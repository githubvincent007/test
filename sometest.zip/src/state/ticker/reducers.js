// reducers.js
import config from 'config'
export  { initialState, reducer }

import {
  PRIMARY_EXAMPLE_ACTION, RECEIVE_POSTS, RECEIVE_DROPDOWN
} from 'state/action-types.js'


const initialState = {
 tickers: [],
  reducer:{}
}

// Never mutate original state passed in. Read
// on redux principles
function reducer(state = initialState.reducer, action){

  switch (action.type) {

    case PRIMARY_EXAMPLE_ACTION: {
      return Object.assign({}, state, {
        name: action.name
      })

    }
          /* we no longer need to receive it bc
          the add a search row would handle it
          and the clear, clears the rows in state
          this is deprecated.

    case RECEIVE_POSTS:
    {
      return Object.assign({}, state, {
        posts: action.posts
      })

    }

           */
      switch (action.type) {
        case RECEIVE_DROPDOWN:
          return action.Days_Requested_Data;
      }
  }

  return state
}
