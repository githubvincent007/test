export default {
  
environment : 'dev', 
adminLinks: [
    {
      label: 'MIO Admin',
      url: 'http://devchi-rpt01.mio.local/MIOAdmin/Common/login.aspx'
    }
  ]

}