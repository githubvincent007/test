export default {
  environment : 'qa'
}