export default {
  environment : 'stg'
}