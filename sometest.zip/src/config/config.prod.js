export default {
  environment : 'prod'
}