// index.js
// Entry point for our application

/*
React + Redux is used to manage state
React-Router for routing
Superagent for AJAX functionality

Best resources for getting up to speed on React+Redux
* https://egghead.io/series/react-fundamentals
* https://egghead.io/series/getting-started-with-redux
* http://redux.js.org/
*/

import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, IndexRoute, IndexRedirect, Link, browserHistory } from 'react-router'
import { Provider } from 'react-redux'

// Root Component
import AppContainer from 'marketdata/AppContainer'
import ManageTickersContainer from 'marketdata/containers/ManageTickers/ManageTickersContainer'

import store from 'state/index.js'
import { PRIMARY_EXAMPLE_ACTION } from 'state/action-types'
import config from 'config'

//Installed so that we can use dataSource stuff
import Kendo from 'kendo/js/kendo.core';

//kendo Professional CSS files (if included don't include kendo-ui-core)
import 'kendo/css/web/kendo.common.min.css';
import 'kendo/css/web/kendo.default.min.css';

// Example dispatch. With React, you will never dispatch directly from store,
// but instead use react-redux plugin to map dispatch to components. Open
// browser console when running project to see this logged (logging middleware
// has been added)
store.dispatch({
  type: PRIMARY_EXAMPLE_ACTION,
  name: 'Example name'
})

 // here here where we keep any component imports within the
import 'styles/main.styl'


import "styles/semantic/components/reset.css"
//<!--import "styles/semantic/components/site.css"

import "styles/semantic/components/container.css"
import "styles/semantic/components/grid.css"
import "styles/semantic/components/header.css"
import "styles/semantic/components/image.css"
import "styles/semantic/components/menu.css"

import "styles/semantic/components/input.css"
import "styles/semantic/components/table.css"
import "styles/semantic/components/label.css"
import "styles/semantic/components/checkbox.css"

import "styles/semantic/components/divider.css"
import "styles/semantic/components/dropdown.css"
import "styles/semantic/components/segment.css"
import "styles/semantic/components/button.css"
import "styles/semantic/components/list.css"
import "styles/semantic/components/icon.css"
import "styles/semantic/components/sidebar.css"
import "styles/semantic/components/transition.css"


import "styles/semantic/components/search.css"


// Import required services

//var x = 0;

ReactDOM.render((
  <Provider store={store}>
    <Router history={browserHistory}>
      <Route path="/marketdata" component={AppContainer} >
        <IndexRedirect to="tickers" />
        <Route path="tickers" component={ManageTickersContainer} />
      </Route>
      <Route path="/">
        <IndexRedirect to="/marketdata" />
      </Route>
    </Router>
  </Provider>
), document.getElementById('root'))
