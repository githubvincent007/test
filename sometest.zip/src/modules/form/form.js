/*
import React from 'react'
import { Base } from 'components/base'
import { Link } from 'react-router'
import { MioLogo } from 'components/mio-logo'
import { Header } from 'components/header'
import { ColumnParent, Column } from 'components/layout'


// grid.js
export default function(props) {
  return (
    <Base>
      <Header height={50}>
          <div className="layout--container">
              <ColumnParent align='edges' className="mio-header">
                  <Column>
                      <MioLogo />
                  </Column>
                  <Column width={600}>

                      <ul className="nav">
                          <li><Link to='/grid' className="link" activeClassName="active">Grid</Link></li>
                          <li><Link to='/form' className="link" activeClassName="active">Form</Link></li>
                      </ul>

                  </Column>
                  <Column>
                      <p>Example text</p>
                  </Column>
              </ColumnParent>
          </div>

      </Header>

      <div className="layout--container layout--primary">
        <h1>Form Example</h1>

        <div className="layout--tmp_img"></div>

      </div>


    </Base>

  )
}*/
