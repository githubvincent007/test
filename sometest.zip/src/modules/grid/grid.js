/*
import React from 'react'
import { Base } from 'components/base'
import { Link } from 'react-router'
import { MioLogo } from 'components/mio-logo'
import { Header } from 'components/header'
import { ColumnParent, Column } from 'components/layout'


// grid.js
//This is a basic example for Grid Control. Features like Sorting, Filtering, Date Filering and Export to Excel as also available in CSD Framework.
export default function(props) {
  return (
    <Base>
      <Header height={50}>
        <div className="layout--container">
        <ColumnParent align='edges' className="mio-header">
          <Column>
            <MioLogo />
          </Column>
          <Column width={600}>
           
            <ul className="nav">
             <li><Link to='/grid' className="link" activeClassName="active">Grid</Link></li>
             <li><Link to='/form' className="link" activeClassName="active">Form</Link></li>
            </ul>

          </Column>
          <Column>
            <p>Example text</p>
          </Column>
        </ColumnParent>
        </div>

      </Header>

      <div className="layout--container layout--primary">
        <h1>Grid Example</h1>
        <ColumnParent gutter={50}>
          <Column>
            <p><b>Open browser console for an example action</b></p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sit amet facilisis ligula. Donec semper sagittis vehicula. Vivamus dui quam, venenatis in leo id, rutrum mollis ante. Praesent consequat odio ac arcu imperdiet, sit amet volutpat nibh luctus. Suspendisse quis ullamcorper mi. Nunc commodo imperdiet purus, tempus cursus ligula hendrerit sed. Curabitur ullamcorper elit eget lectus porttitor, vitae porttitor leo faucibus. Morbi et velit accumsan, tristique libero in, sollicitudin sem. In efficitur, enim non semper lacinia, ante sem faucibus ex, eget tincidunt magna neque tempus massa. Suspendisse molestie condimentum justo, vitae varius lectus venenatis et. Morbi a mi varius justo molestie vestibulum. Aenean venenatis eleifend purus molestie sodales.</p>

          </Column>
          <Column>
            <p>Sed sit amet est nec odio sagittis scelerisque vel at neque. Mauris sem nibh, sagittis at tincidunt at, pharetra et leo. Mauris sit amet orci lectus. Maecenas metus dolor, dignissim non dui et, porttitor scelerisque massa. Nam nec dolor blandit diam ullamcorper interdum. Mauris id tristique ante. Quisque fringilla, sem et tincidunt accumsan, ipsum sapien ullamcorper leo, in ultricies massa turpis ac ante. Phasellus sollicitudin auctor risus, sed dignissim urna. Morbi semper euismod placerat. Aliquam suscipit velit non ex tristique bibendum. Sed viverra dictum felis eget scelerisque. Vivamus dictum quis nisl ut vehicula.</p>
          </Column>
        </ColumnParent>

      </div>


    </Base>

  )
}*/
