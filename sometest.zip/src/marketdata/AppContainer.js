// AppContainer.js
// Root component for our application
import App from './App.js'
import { connect } from 'react-redux'

function mapStateToProps(state){
  return {
    isLoading: state.isLoading
  }
}

const mapDispatchToProps = (dispatch) => {
  return {}
}

export default connect(mapStateToProps, mapDispatchToProps)(App)
