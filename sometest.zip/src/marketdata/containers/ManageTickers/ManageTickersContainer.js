import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as tableActions from '../../../state/ticker/TableActions';
import * as postActions from '../../../state/ticker/actions';
import ManageTickers from './ManageTickers'

function mapStateToProps(state) {

  //need to change this to rows but code breaks
 //const{Rows} = state
 // return {
  //  initialState: state.initialState,
   // Rows
  //};
  return {
    tableRows: state.tickers
    // tableRows: state.

  };


}

function mapDispatchToProps(dispatch) {

  const mergedActions = {tableActions ,postActions };

  return {
    actions: bindActionCreators(tableActions, dispatch),
    postactions:bindActionCreators(postActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps )(ManageTickers)
