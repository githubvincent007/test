import React, {Component, PropTypes} from 'react';
//import ReactDataGrid from 'react-data-grid';
//import KendoGrid from 'kendo-ui-react-jquery-grid';
//Installed so that we can use dataSource stuff
import Kendo from 'kendo/js/kendo.core';
import KendoGrid from 'kendo-ui-react-jquery-grid';

//kendo Professional CSS files (if included don't include kendo-ui-core)
import 'kendo/css/web/kendo.common.min.css';
import 'kendo/css/web/kendo.blueopal.min.css';
import {$} from 'jquery';








import NewTableRow from '../../components/TableRows/NewTableRow';
import SearchedTableRow from '../../components/TableRows/SearchedTableRow';
import EditTableRow from '../../components/TableRows/EditTableRow';
import SavedTableRow from '../../components/TableRows/SavedTableRow';

//import {  fetchPosts2 } from '../../../state/actions';
class ManageTickers extends Component {

  constructor (props) {
    super();

    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleNewTicker = this.handleNewTicker.bind(this);
    this.handleEdit = this.handleEdit.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.handleEnter = this.handleEnter.bind(this);
    this.handleClearRows = this.handleClearRows.bind(this);
    this.state = {currentNewId:-1};

  }

  handleNewTicker(e)
  {
    this.setState({currentNewId: this.state.currentNewId-1});


    this.props.actions.NEW_TICKER_ROW(this.state.currentNewId);

  }

  handleClearRows( )  {

    this.props.actions.CLEAR_ROWS();

  }



  handleEdit(row_tickerid)  {

    this.props.actions.EDIT_A_ROW(row_tickerid);

  }




  handleSave(row_tickerid, save_a_row)  {

    var asset= "US Equity";

    switch (save_a_row.MIO_Asset_Class) {
      case 1:
         asset = "US Equity";
        break;
      case 2:
        asset = "Credit";
        break;
      case 3:
        asset = "Fixed Income";
        break;
      case 4:
        asset = "Commodities";
        break;
    }
    var _tickerid = null
    if(row_tickerid < 0 )
    {
      _tickerid = null
    }
    else
    {
      _tickerid = row_tickerid
    }

   var save_a_row = {

      "TICKER_ID": null,
      "SYSTEM_ID": 1,
      "TICKER_CODE": save_a_row.NAME,
      "MIO_NAME": save_a_row.MIO_NAME,
      "MIO_ASSET_CLASS": null,
      "NAME": save_a_row.NAME,
      "DAYS_REQUESTED_HISTORY": save_a_row.Hist_Restated_Data,
      "DAYS_REQUESTED_FUTURE": save_a_row.Future_Restated_Data,
      "DAYS_REQUESTED_FULL_HISTORY": save_a_row.One_Time_History_Load,
      "TICKER_TYPE_ID": 6,
      "IS_TICKER_DISABLED": save_a_row.Disable_Ticker==true ? 1: 0,
      "IS_GET_FULL_HISTORY": save_a_row.One_Time_History_Load == true ? 1: 0,
      "DOWNLOAD_TYPES_LIST": "1",
      "FREQUENCY_LIST": "1",
      "MOD_USER_ID": 1,
      "LIC_CAT_DERIVED_DATA": save_a_row.Derived_Data==true ? 1:0,
      "LIC_CAT_END_OF_DAY_PRICING":save_a_row.End_Of_Day_Pr == true ? 1: 0,
      "LIC_CAT_ESTIMATES":save_a_row.Estimates== true ? 1: 0,
      "LIC_CAT_FUNDAMENTALS":save_a_row.Fundamentals== true ? 1: 0,
      "LIC_CAT_HISTORICAL_TIME_SERIES":save_a_row.Hist_Time_Srs== true ? 1:0,
      "LIC_CAT_SECURITY_MASTER":save_a_row.Sec_Master == true ? 1: 0,
      "LIC_CAT_USER_ENTERED_INFO":save_a_row.User_Entered == true ? 1:0,
      "LIC_QUOTE_COMPOSITE":save_a_row.Quote_Comp == true ?1:0,
      "LIC_CORPORATE_ACTIONS" : save_a_row.Corp_Action== true ?1:0,
      "LIC_CREDIT_RISK":save_a_row.Credit_Risk == true ?1:0,
      "LIC_NOT_DOWNLOADABLE":1

  };



/*
    var save_a_row ={
      "TICKER_ID": null,
      "SYSTEM_ID": 1,
      "TICKER_CODE": save_a_row.NAME,
      "MIO_NAME": save_a_row.MIO_NAME,
      "MIO_ASSET_CLASS": asset,
      "NAME":  save_a_row.NAME,
      "COUNTRY": save_a_row.COUNTRY,
      "CRNCY": save_a_row.CURRENCY,
      "DAYS_REQUESTED_HISTORY": save_a_row.Hist_Restated_Data,
      "DAYS_REQUESTED_FUTURE": save_a_row.Future_Restated_Data,
      "DAYS_REQUESTED_FULL_HISTORY": save_a_row.One_Time_History_Load,
      "TICKER_TYPE_ID": 6,
      "IS_TICKER_DISABLED": save_a_row.Disable_Ticker,
      "IS_GET_FULL_HISTORY": save_a_row.One_Time_History_Load > 0 ? 1: 0,
      "DOWNLOAD_TYPES_LIST": "1",
      "FREQUENCY_LIST": "1",
      "MOD_USER_ID": 1,
      "LIC_CAT_DERIVED_DATA": save_a_row.Derived_Data,
      "LIC_CAT_END_OF_DAY_PRICING":save_a_row.End_Of_Day_Pr,
      "LIC_CAT_ESTIMATES":save_a_row.Estimates,
      "LIC_CAT_FUNDAMENTALS":save_a_row.Fundamentals,
      "LIC_CAT_HISTORICAL_TIME_SERIES":save_a_row.Hist_Time_Srs,
      "LIC_CAT_SECURITY_MASTER":save_a_row.Sec_Master,
      "LIC_CAT_USER_ENTERED_INFO":save_a_row.User_Entered,
      "LIC_QUOTE_COMPOSITE":save_a_row.Quote_Comp,
      "LIC_CORPORATE_ACTIONS" : save_a_row.Corp_Action,
      "LIC_CREDIT_RISK":save_a_row.Credit_Risk,
      "LIC_NOT_DOWNLOADABLE":1
    }
*/







    this.props.actions.SAVE_A_ROW(row_tickerid, save_a_row  );

  }



  handleSubmit(e)  {

    // var _search = this.refs.searchbox.value;
    // console.log(this.refs.searchbox.value + "is dispatched");
    // this.props.dispatch(fetchPosts(_search));
  }

  handleEnter(e)
  {
    if(e.charCode === 13)
    {
      e.preventDefault(); // Ensure it is only this code that rusn

      var _search = this.refs.searchbox.value;
      console.log(this.refs.searchbox.value + "is dispatched");
      this.props.postactions.fetchSearch(_search);
     // this.props.dispatch(fetchPosts(_search));
     // alert("Enter was pressed was presses");
    }


  }



  renderDropDown() {

    //$(this.refs.OneHistLoad).dropdown();

}

  componentDidMount() {
  //$(this.refs.OneHistLoad).dropdown();






    //jQuery($(ReactDOM.findDOMNode(this))).










  }

  componentDidUpdate() {
 //   this.renderDropDown();

  }

  render () {









if(this.props.tableRows != undefined) {

  var displayRows = this.props.tableRows.map(function (_ROW) {


    switch (_ROW.Row_Status) {
      case "NEW":
        return <NewTableRow rowData={_ROW} handleSave={this.handleSave}/>;
      case "EDIT":
        return <EditTableRow rowData={_ROW} handleSave={this.handleSave}/>;
      case "SAVED":
        return <SavedTableRow rowData={_ROW}/>;
      case "SEARCHED":
        return <SearchedTableRow rowData={_ROW} handleEdit1={this.handleEdit}/>;
      default:
        return <NewTableRow rowData={_ROW}/>;
    }
  }, this);

}






    return (

      <div className="ui grid" style={{'overflow': 'auto'}}>
        <div className="row">
          <div className="left floated column">

            <div className="ui search" style={{padding: 50}}>
              <div className="ui icon input">
                <input className="prompt" ref="searchbox" type="text" placeholder="Tickers Search..." onKeyPress={this.handleEnter}/>
                <i className="search icon"/>
              </div>
              <div className="results"></div>
            </div>

          </div>
        </div>

        <div className="row" style={{padding:25}}>

          <KendoGrid options={{height: 550,sortable: true}}>
            <table id="grid">
              <colgroup>
                <col />
                <col />
                <col style={{width:110}} />
                <col style={{width:120}} />
                <col style={{width:130}} />
              </colgroup>
              <thead>
              <tr>
                <th data-field="make">Car Make</th>
                <th data-field="model">Car Model</th>
                <th data-field="year">Year</th>
                <th data-field="category">Category</th>
                <th data-field="airconditioner">Air Conditioner</th>
              </tr>
              </thead>
              <tbody>
              <tr>
                <td>Volvo</td>
                <td>S60</td>
                <td>2010</td>
                <td>Saloon</td>
                <td>Yes</td>
              </tr>
              <tr>
                <td>Audi</td>
                <td>A4</td>
                <td>2002</td>
                <td>Saloon</td>
                <td>Yes</td>
              </tr>
              <tr>
                <td>BMW</td>
                <td>535d</td>
                <td>2006</td>
                <td>Saloon</td>
                <td>Yes</td>
              </tr>
              <tr>
                <td>BMW</td>
                <td>320d</td>
                <td>2006</td>
                <td>Saloon</td>
                <td>No</td>
              </tr> <tr>
                <td>Lancia</td>
                <td>Ypsilon</td>
                <td>2006</td>
                <td>Hatchback</td>
                <td>Yes</td>
              </tr>
              </tbody>
            </table>
          </KendoGrid>

          </div>
      </div>
    );
  }


}

export default ManageTickers;
