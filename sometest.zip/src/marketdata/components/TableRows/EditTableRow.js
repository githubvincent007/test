/**
 * Created by vinay damarla on 9/26/2016.
 */
/**
 * Created by webstorm on 9/25/2016.
 */
/**
 * Created by webstorm on 9/25/2016.
 */


import React, { Component, PropTypes } from 'react';
import classnames from 'classnames';

export default class EditTableRow extends Component {

  constructor (props) {
    super();

    this.handleChange = this.handleChange.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.state = {
      NAME:props.rowData.Name,
      MIO_Name:props.rowData.MIO_Name,
      COUNTRY: props.rowData.Country,
      CURRENCY:props.rowData.Currency,
      MIO_Asset_Class: 1,
      One_Time_History_Load: props.rowData.One_Time_History_Load,
      Hist_Restated_Data:props.rowData.Hist_Restated_Data,
      Blmbg_Pricing_Src:props.rowData.Blmbg_Pricing_Src,
      Future_Restated_Data:props.rowData.Future_Restated_Data,
      Returns_Measure:props.rowData.Returns_Measure,
      Disable_Ticker: props.rowData.Disable_Ticker,
      Derived_Data: props.rowData.Derived_Data,
      End_of_Day_Pr: props.rowData.End_of_Day_Pr,
      Estimates: props.rowData.Estimates,
      Fundamentals: props.rowData.Fundamentals,
      Hist_Time_Srs: props.rowData.Hist_Time_Srs,
      Sec_Master: props.rowData.Sec_Master,
      User_Entered:props.rowData.User_Entered,
      Quote_Comp:props.rowData.Quote_Comp,
      Corp_Action: props.rowData.Corp_Action,
      Credit_Risk:props.rowData.Credit_Risk
    };
  }
  //getInitialState() {
  // return {value: 'Hello!'};
  //}

  handleClick(event) {

    this.setState({ISDIRTY:1});
    //alert('got hit');
    switch(event.target.id) {
      case "DISABLE_TICKER":
        this.setState({Disable_Ticker: event.target.checked});
        break;
      case "DERIVED_DATA":
        this.setState({Derived_Data: event.target.checked});
        break;
      case "END_OF_DAY_PR":
        this.setState({End_Of_Day_Pr: event.target.checked});
        break;
      case "ESTIMATES":
        this.setState({Estimates : event.target.checked});
        break;
      case "FUNDAMENTALS":
        this.setState({Fundamentals : event.target.checked});
        break;
      case "HIST_TIME_SRS":
        this.setState({Hist_Time_Srs : event.target.checked});
        break;
      case "SEC_MASTER":
        this.setState({Sec_Master : event.target.checked});
        break;
      case "USER_ENTERED":
        this.setState({User_Entered : event.target.checked});
        break;
      case "QUOTE_COMP":
        this.setState({Quote_Comp : event.target.checked});
        break;
      case "CORP_ACTION":
        this.setState({Corp_Action : event.target.checked});
        break;
      case "CREDIT_RISK":
        this.setState({Credit_Risk : event.target.checked});
        break;
      default:
      //   alert('default');
    }
  }
  handleChange(event)
  {
    this.setState({ISDIRTY:1});

    switch(event.target.id) {
      case "NAME":
        this.setState({NAME: event.target.value});
        break;
      case "MIO_NAME":
        this.setState({MIO_NAME: event.target.value});
        break;
      case "COUNTRY":
        this.setState({COUNTRY: event.target.value});
        break;
      case "CURRENCY":
        this.setState({CURRENCY: event.target.value});
        break;
      case "MIO_ASSET_CLASS":
        this.setState({MIO_Asset_Class: event.target.value});
        break;
      case "ONE_TIME_HISTORY_LOAD":
        this.setState({One_Time_History_Load: event.target.value});
        break;
      case "HIST_RESTATED_DATA":
        this.setState({Hist_Restated_Data: event.target.value});
        break;
      case "BLMBG_PRICING_SRC":
        this.setState({Blmbg_Pricing_Src: event.target.value});
        break;
      case "FUTURE_RESTATED_DATA":
        this.setState({Future_Restated_Data: event.target.value});
        break;
      case "RETURNS_MEASURE":
        this.setState({Returns_Measure: event.target.value});
        break;
      default:

    }
    //this.setState({value: event.target.value});
  }

  /*
   static propTypes = {

   };
   */

  /*
   TO DO : REPLACE THESE STUPID SELECT COMPONENTS INTO A
   REACT-SELECT TOOLS



   */


  render () {
    return (
      <tr>
        <td className="collapsing">
          {/*--<div className="ui fitted checkbox">
           <input type="checkbox"></input>
           </div> */}
          {this.state.ISDIRTY==1 ? <button className="ui yellow button" onClick={(evt) =>this.props.handleSave(this.props.rowData.Ticker_ID, this.state)} >Save</button> : <div></div>}
        </td>


        <td>
          {/* Name */}
          <div className="ui input">
            <input type="text" id="NAME" placeholder="Enter..." value={this.state.NAME} onChange={this.handleChange}/>
          </div>

        </td>
        <td>
          {/*MIO Name */}
          <div className="ui input">
            <input type="text" id="MIO_NAME" placeholder="Enter..." value={this.state.MIO_NAME} onChange={this.handleChange} />
          </div>

        </td>
        <td>
          {/*Mio Asset Class  */}
          <select className="ui dropdown" value={this.state.MIO_Asset_Class} id="MIO_ASSET_CLASS" onChange={this.handleChange}>
            <option value="">Asset Class</option>
            <option value="1">US Equity</option>
            <option value="2">Credit</option>
            <option value="3">Fixed Income</option>
            <option value="4">Commodities</option>
          </select>

        </td>


        <td>
          {/* Country  */}
          <div className="ui input">
            <input type="text" id="COUNTRY" placeholder="Enter..." value={this.state.COUNTRY} onChange={this.handleChange} />
          </div>

        </td>


        <td>
          {/* Currency */}
          <div className="ui input">
            <input type="text" id="CURRENCY" placeholder="Enter..." value={this.state.CURRENCY} onChange={this.handleChange} />
          </div>

        </td>


        <td>
          {/* 5 One Time Hist Load */}
          <select className="ui dropdown" value={this.state.One_Time_History_Load} id="ONE_TIME_HISTORY_LOAD" onChange={this.handleChange}>
            <option value="0">None</option>
            <option value="31">One Month</option>
            <option value="365">One Year</option>
            <option value="730">Two Years</option>
            <option value="1825">Five Years</option>
          </select>

        </td>

        <td>
          {/*  6 Historical Restated data */}
          <select className="ui dropdown" value={this.state.Hist_Restated_Data} id="HIST_RESTATED_DATA" onChange={this.handleChange}>
            <option value="0">None</option>
            <option value="31">One Month</option>
            <option value="365">One Year</option>
            <option value="730">Two Years</option>
            <option value="1825">Five Years</option>
          </select>

        </td>
        <td>
          {/*  7 Bloomberg Pricing Source */}
          <select className="ui dropdown" value={this.state.Blmbg_Pricing_Src} id="BLMBG_PRICING_SRC" onChange={this.handleChange}>
            <option value="">None</option>
            <option value="1">BLOOMBERG</option>
            <option value="2">BVAL</option>
          </select>

        </td>

        <td>

          {/*  8 Future Restated data */}
          <select className="ui dropdown" value={this.state.Future_Restated_Data} id="FUTURE_RESTATED_DATA" onChange={this.handleChange}>
            <option value="0">None</option>
            <option value="31">One Month</option>
            <option value="365">One Year</option>
            <option value="730">Two Years</option>
            <option value="1825">Five Years</option>
          </select>
        </td>

        <td>
          {/*  9 Primary Measure */}
          <select className="ui dropdown" value={this.state.Returns_Measure} id="RETURNS_MEASURE" onChange={this.handleChange}>
            <option value="0">None</option>
            <option value="31">One Month</option>
            <option value="365">One Year</option>
            <option value="730">Two Years</option>
            <option value="1825">Five Years</option>
          </select>

        </td>


        <td>
          {/* 10 Disable Tickers */}
          <div className="ui fitted checkbox">
            <input type="checkbox" id="DISABLE_TICKER"  checked={this.state.Disable_Ticker} onChange={this.handleClick}  />
            <label></label>
          </div>

        </td>
        <td>
          {/* 11 Derived data */}
          <div className="ui fitted checkbox" >
            <input type="checkbox" id="DERIVED_DATA"  checked={this.state.Derived_Data} onChange={this.handleClick}  />
            <label></label>
          </div>

        </td>
        <td>
          {/* 12 End of Day Pricing */}
          <div className="ui fitted checkbox">
            <input type="checkbox" id="END_OF_DAY_PR"  checked={this.state.End_Of_Day_Pr} onChange={this.handleClick}  />
            <label></label>
          </div>

        </td>
        <td>
          {/* 13 Estimates */}
          <div className="ui fitted checkbox">
            <input type="checkbox"  id="ESTIMATES"  checked={this.state.Estimates} onChange={this.handleClick} />
            <label></label>
          </div>
        </td>
        <td>
          {/* 14 Fundamentals */}

          <div className="ui fitted checkbox">
            <input type="checkbox"  id="FUNDAMENTALS"  checked={this.state.Fundamentals} onChange={this.handleClick} />
            <label></label>
          </div>

        </td>
        <td>

          {/* 15 Historical Time Series */}
          <div className="ui fitted checkbox">
            <input type="checkbox"   id="HIST_TIME_SRS"  checked={this.state.Hist_Time_Srs} onChange={this.handleClick}  />
            <label></label>
          </div>

        </td>
        <td>
          {/* 16 Sec Master*/}
          <div className="ui fitted checkbox">
            <input type="checkbox"  id="SEC_MASTER"  checked={this.state.Sec_Master} onChange={this.handleClick}  />
            <label></label>
          </div>

        </td>
        <td>
          {/* 17 User Entered */}
          <div className="ui fitted checkbox">
            <input type="checkbox"  id="USER_ENTERED"  checked={this.state.User_Entered} onChange={this.handleClick}  />
            <label></label>
          </div>
        </td>
        <td>
          {/* 18 Quote-Comp */}
          <div className="ui fitted checkbox">
            <input type="checkbox" id="QUOTE_COMP"  checked={this.state.Quote_Comp} onChange={this.handleClick}  />
            <label></label>
          </div>

        </td>
        <td>
          {/* 19 corp Actions */}
          <div className="ui fitted checkbox">
            <input type="checkbox" id="CORP_ACTION"  checked={this.state.Corp_Action} onChange={this.handleClick}  />
            <label></label>
          </div>
        </td>

        <td>
          {/* 20 credit Risk */}
          <div className="ui fitted checkbox">
            <input type="checkbox" id="CREDIT_RISK"  checked={this.state.Credit_Risk} onChange={this.handleClick}  />
            <label></label>
          </div>
        </td>

        <td>
          {/* 21 ticker id */}
          <div class="ui label">
            <div class="detail">{this.props.rowData.Ticker_ID}  </div>
          </div>
        </td>

        <td>
          {/* 22 row status */}
          <a className="ui blue label">{this.props.rowData.Row_Status}</a>
        </td>
        <td>
          {this.state.ISDIRTY==1 ? <i className="large black checkmark icon"></i> : <div className="ui green label">No</div> }
        </td>

      </tr>






    );
  }
}
