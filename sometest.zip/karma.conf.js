var webpack = require('webpack');
var path = require('path')

module.exports = function (config) {
  config.set({
    // browsers: [ 'Chrome' ], //run in Chrome
    browsers: [ 'PhantomJS' ], //run in Chrome
    singleRun: true, //just run once by default
    frameworks: [ 'mocha', 'sinon' ], //use the mocha test framework
    files: [
      'tests.bundle.js' //just load this file
    ],
    preprocessors: {
      'tests.bundle.js': [ 'webpack', 'sourcemap' ] //preprocess with webpack and our sourcemap loader
    },
    reporters: [ 'mocha' ], //report results in this format
    plugins: [
      'karma-chrome-launcher',
      'karma-phantomjs-launcher',
      'karma-mocha',
      'karma-mocha-reporter',
      'karma-sourcemap-loader',
      'karma-webpack', // *** This 'registers' the Karma webpack plugin.
      'karma-sinon'
    ],
    webpack: { //kind of a copy of your webpack config
      resolve: {
        extensions: ['', '.js', '.jsx'],
        root: path.resolve(__dirname, './src'),
        alias: {
          // We stick to dev config for testing, but needs to be defined
          // here so import resolves properly
          'envConfig' : path.resolve(__dirname, './src/config.dev.js'),
          'theme': path.resolve(__dirname, './src/app/styles/variables.styl')
        }
      },
      devtool: 'inline-source-map', //just do inline source maps instead of the default
      module: {
        loaders: [
          {
            test: /\.js$/,
            include:/src/,
            loader: 'babel',
            query: {
              presets: ['airbnb']
            }
          }
        ]
      },
      externals: {
        'cheerio': 'window',
        'react/addons': true,
        'react/lib/ExecutionEnvironment': true,
        'react/lib/ReactContext': true
      }
    },
    webpackServer: {
      noInfo: true //please don't spam the console when running in karma!
    }
  });
};
