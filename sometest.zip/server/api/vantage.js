var request = require('superagent');
var Promise = require("bluebird");
var jwt = require('jsonwebtoken');
var jwtMiddleware = require('express-jwt');
const binaryParser = require('superagent-binary-parser');
const fs = require('fs');
var api = require('./utils.js')
var http = require('http');


// http://devchi-lnx-ws01:5755/mass/cs_resource/get_balances_by_fmno?fmno=79805998&&asofdt=2016-06-12
// http://localhost:8080/api/vantage/balances?fmno=79805998&&asofdt=2016-06-12
exports.getBalances = (req, res) => {
  api.get({
    method:'get_balances_by_fmno',
    query: req.query
  }).then(function(data){
    res.json(data)
  })
};


// http://devchi-lnx-ws01:5755/mass/cs_resource/get_transactions_by_fmno?fmno=15623922&startdt=2014-01-01&enddt=2016-06-01
// http://localhost:8080/api/vantage/transactions?fmno=15623922&startdt=2014-01-01&enddt=2016-06-01
exports.getTransactions = (req, res) => {
  api.get({
    method:'get_transactions_by_fmno',
    query: req.query
  }).then(function(data){
    res.json(data)
  })
};

// http://devchi-lnx-ws01:5755/mass/cs_resource/get_csd_user_tax_documents?fmno=32979285&doc_category=1,7,&siteID=34&no_stmts=5
// http://localhost:3000/api/vantage/statements?fmno=32979285&doc_category=1,7,&siteID=34&no_stmts=5
exports.getStatements = (req, res) => {
  api.get({
    method:'get_csd_user_tax_documents',
    query: req.query
  }).then(function(data){
    res.json(data)
  })
};

// http://devchi-lnx-ws01:5755/mass/cs_resource/get_csd_statements_document?doc_id=365629&doc_name=27998-9-062016-38.pdf&user_id=CSD
// http://localhost:8080/api/vantage/single-statement?doc_id=365629&doc_name=27998-9-062016-38.pdf&user_id=CSD
exports.getSingleStatementLink = (req, res) => {

    var url ="http://devchi-lnx-ws01:5855/mass/cs_resource/get_csd_statements_document?doc_id=365629&doc_name=27998-9-062016-38.pdf&user_id=CSD";
    request.get(url).pipe(res);
    return

};

