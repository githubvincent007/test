var request = require('superagent');
var Promise = require("bluebird");
var jwt = require('jsonwebtoken');
var api = require('./utils.js')

// app.get('/api/data', jwtMiddleware({secret:fakePrivateKey}), api.getContact);
// app.get('/api/login', api.logIn);
// app.get('/authenticate', (req,res)=>{
// });


function generateToken(username){
  // Options for JWT
  const options = {
    expiresIn: '30m'
  }

  return jwt.sign({
    username: username
  },process.env.JWT_KEY, options)
}

exports.authenticate = (req,res)=> {
  
  // Token created for MASS authentication call,
  // not sent back to client!
  const authToken = jwt.sign({
    username: req.query.username,
    password: req.query.password
  },process.env.JWT_KEY)
  
  api.get({ 
    method:'get_authentication_payload',
    query: {
      payload: authToken
    }
  }).then(function(data){
    // Incorrect credentials
    if (data.valid === false){
      res.json({
        status: 401,
        reason: 'IncorrectCredentials',
        token: null
      })
    // Valid login!
    // ----------------------------
    } else if (data.valid === true) {

      const username = req.query.username
      
      api.get({ 
        method:'get_ad_groups',
        query: {
          username: username
        }
      }).then(data=>{
        // Confirm user is part of allowed groups
        const allowedGroups = process.env.AD_GROUPS.split(',');
        const isValidGroup = data[username].some(function (v) {
          return allowedGroups.indexOf(v) >= 0;
        });
        // Valid credentials and access, return proper token
        if (isValidGroup) {
          res.json({
            status: 200,
            username: req.query.username,
            token: generateToken(req.query.username)
          })
        // Valid credentials BUT no access
        } else {
          res.json({
            status: 401,
            reason: 'MissingAccessGroup',
            token: null
          })
        }
      })
    // 'Other' issues
    } else {
      res.json({
        status: 500,
        reason: 'ServerIssue',
        token: null
      })
    }
  })
    
}

exports.validateToken = (req, res) => {
  const token = req.headers.authorization.split(' ')[1]
  

  jwt.verify(token, process.env.JWT_KEY, (err, decoded)=>{
  // Unauthorized, reject
  if (err) {
    res.json({
      status: 403,
      error: err
    })
  //
  } else {
    res.json({
      status: 200,
      token: generateToken(decoded.username),
      username: decoded.username
    })
  }


})

}

