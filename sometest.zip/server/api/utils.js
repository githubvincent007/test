const Q = require('q');
const Promise = require('bluebird');
const request = require('superagent');

// config
// .base
// .resource
// .method
// .query
exports.get = config => {


  if (config === false)
    return false;

  return new Promise((resolve, reject)=>{
  config.base = config.base || process.env.MASS_URL;
  config.resource = config.resource || 'cs_resource'

  var url = config.base + config.resource + '/' + config.method

  return request
    .get(url)
      .query(config.query)
      .set('Content-Type', 'application/pdf')
      .set('Content-Disposition', 'inline; filename=27998-9-062016-38.pdf')
      .set('Accept', 'application/json')
      .end(function(err, response){
        if (response.body.success) {
          resolve(response.body.data)
        } else {
          console.log('response')
          // console.log(response)
          resolve(response)          
        }

        

        
      })    
  })


}
