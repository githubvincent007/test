
var lusca = require('lusca');
var bodyParser = require('body-parser');
var express = require('express');
var path = require('path');
var logger = require('logger');
var favicon = require('serve-favicon');
var ejs = require('ejs');
var unless = require('express-unless');

require('dotenv').config();

/**
 * Create Express server.
 */
const app = express();


const api = require('./api');

// app.use(favicon(__dirname + '/public/favicon.ico'));

/**
 * Express configuration.
 */
app.set('port', process.env.PORT || 3000);

app.set('views', path.join(__dirname, 'build'));
app.set('view engine', 'ejs');
// app.use(compression());
// app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
var jwtMiddleware = require('express-jwt');

// app.use(expressValidator());
// app.use(session({
//   resave: true,
//   saveUninitialized: true,
//   secret: process.env.SESSION_SECRET,
//   store: new MongoStore({
//     url: process.env.MONGODB_URI || process.env.MONGOLAB_URI,
//     autoReconnect: true
//   })
// }));
// app.use(passport.initialize());
// app.use(passport.session());
// app.use(flash());
// app.use((req, res, next) => {
//   if (req.path === '/api/upload') {
//     next();
//   } else {
//     lusca.csrf()(req, res, next);
//   }
// });
// app.use(lusca.xframe('SAMEORIGIN'));
// app.use(lusca.xssProtection(true));
app.use((req, res, next) => {
  res.locals.user = req.user;
  next();
});
// app.use((req, res, next) => {
//   // After successful login, redirect back to /api, /contact or /
//   if (/(api)|(contact)|(^\/$)/i.test(req.path)) {
//     req.session.returnTo = req.path;
//   }
//   next();
// });

// Excluded from requiring JWT
const publicApiRoutes = [
'/api/authenticate',
'/api/validate',
'/api/vantage/single-statement'
]

// Routes
// app.use('/api', api)
app.use('/api', jwtMiddleware({secret:process.env.JWT_KEY}).unless({path:publicApiRoutes}), api)
// 
const siteRoot = path.join(__dirname, '..', '/build');
app.use('/',  express.static(siteRoot, { maxAge: 31557600000 }));
app.use('/*', express.static(siteRoot, { maxAge: 31557600000 }));






/**
 * Error Handler.
 */
// app.use(errorHandler());

/**
 * Start Express server.
 */
app.listen(app.get('port'), () => {
  console.log('Express server listening on port %d in %s mode', app.get('port'), app.get('env'));
});

module.exports = app;